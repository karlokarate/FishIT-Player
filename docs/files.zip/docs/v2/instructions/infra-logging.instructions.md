---
applyTo:
  - infra/logging/**
---

# Copilot Instructions: infra/logging

> **Module Purpose:** Unified logging infrastructure.  This is the ONLY module 
> allowed to depend on Timber, android.util.Log, or logging backends.

---

## 🔴 HARD RULES (from LOGGING_CONTRACT_V2.md)

### 1. This Module OWNS All Logging Dependencies
```kotlin
// ✅ ALLOWED ONLY in infra/logging
import timber.log.Timber
import android.util. Log
import com.google.firebase.crashlytics.*  // If used
```

### 2. All Other Modules Use UnifiedLog
```kotlin
// ✅ CORRECT:  Lambda-based (preferred, lazy evaluation)
UnifiedLog.d(TAG) { "Processing item $id with value $value" }
UnifiedLog.e(TAG, throwable) { "Failed to load:  $error" }

// ✅ ALLOWED: String-based for constants
UnifiedLog.i(TAG, "Starting sync")

// ❌ FORBIDDEN outside infra/logging
Timber.d("message")
Log.d(TAG, "message")
println("debug")
System.out.println("debug")
```

### 3. Initialization in app-v2 Only
```kotlin
// In app-v2 Application. onCreate():
UnifiedLogInitializer.init(isDebug = BuildConfig.DEBUG)
```

---

## 📋 UnifiedLog API

| Method | Usage |
|--------|-------|
| `UnifiedLog.v(tag) { msg }` | Verbose (lazy) |
| `UnifiedLog.d(tag) { msg }` | Debug (lazy) |
| `UnifiedLog.i(tag) { msg }` | Info (lazy) |
| `UnifiedLog.w(tag) { msg }` | Warning (lazy) |
| `UnifiedLog.e(tag, throwable?) { msg }` | Error (lazy) |

**Prefer lambda-based for:**
- String interpolation (`"value = $x"`)
- Expensive toString() calls
- Hot paths

---

## ⚠️ Common Violations

```kotlin
// ❌ FORBIDDEN in v2 modules (except infra/logging)
Timber. d("message")           // Use UnifiedLog
Log.d(TAG, "message")         // Use UnifiedLog
println("debug")              // Use UnifiedLog
e. printStackTrace()           // Use UnifiedLog. e(tag, e) { msg }
```

---

## 📚 Reference Documents

- `/contracts/LOGGING_CONTRACT_V2.md`
- `/AGENTS.md` - Section 5.1
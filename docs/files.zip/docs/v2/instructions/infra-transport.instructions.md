---
applyTo:
  - infra/transport-telegram/**
  - infra/transport-xtream/**
---

# Copilot Instructions: infra/transport-*

> **Module Purpose:** Network/file access layer.  Wraps external APIs (TDLib, HTTP) 
> and exposes typed interfaces with wrapper DTOs to higher layers.

---

## 🔴 HARD RULES

### 1. Transport Produces Wrapper DTOs, NOT RawMediaMetadata
```kotlin
// ✅ CORRECT: Transport returns wrapper types
interface TelegramHistoryClient {
    suspend fun getMessages(chatId: Long): List<TgMessage>  // Wrapper DTO
}

// ❌ FORBIDDEN: Transport returning pipeline/model types
suspend fun getMedia(): List<RawMediaMetadata>      // WRONG
suspend fun getItems(): List<TelegramMediaItem>     // WRONG - pipeline DTO
```

### 2. Hide Implementation Details
```kotlin
// ✅ CORRECT:  Expose typed interfaces
interface TelegramAuthClient { ...  }
interface TelegramHistoryClient { ... }
interface TelegramFileClient { ... }

// ❌ FORBIDDEN: Exposing internals to upper layers
fun getTdlibClient(): TdlibClientProvider  // WRONG - v1 legacy pattern! 
fun getRawTdApi(): TdApi. Client            // WRONG - TDLib types leak
```

### 3. TdlibClientProvider is FORBIDDEN for External Use
```kotlin
// ❌ FORBIDDEN: v1 legacy pattern - MUST NOT be reintroduced
class SomeClass(
    private val tdlibProvider: TdlibClientProvider  // VIOLATION!
)

// ✅ CORRECT: Use typed interfaces
class SomeClass(
    private val authClient: TelegramAuthClient,
    private val historyClient: TelegramHistoryClient,
)
```

### 4. No Upper Layer Imports
```kotlin
// ✅ ALLOWED
import com.fishit.player.core.model.*  // Core primitives only

// ❌ FORBIDDEN
import com.fishit.player.pipeline.*    // Pipeline
import com.fishit.player.infra.data.*  // Data layer
import com.fishit. player.playback.*    // Playback
import com.fishit.player.feature.*     // UI
```

---

## 📋 Telegram Transport Interfaces

| Interface | Purpose |
|-----------|---------|
| `TelegramAuthClient` | Login, logout, auth state |
| `TelegramHistoryClient` | Chat history → `TgMessage` |
| `TelegramFileClient` | File downloads → `TgFile` |
| `TelegramThumbFetcher` | Thumbnails for Coil |

**Internal (NOT exported):**
- `DefaultTelegramClient` - implements all interfaces
- `TdlibClientProvider` - ⚠️ LEGACY, internal only

---

## 📋 Wrapper DTOs

| DTO | Purpose |
|-----|---------|
| `TgMessage` | Message wrapper |
| `TgChat` | Chat wrapper |
| `TgContent` | Media content (video, audio, doc) |
| `TgThumbnail` | Thumbnail wrapper |

---

## 📐 Layer Position

```
Transport ← Pipeline ← Data ← Domain ← UI
    ▲
YOU ARE HERE (bottom of stack)
```

---

## 📚 Reference Documents

- `/infra/transport-telegram/README.md`
- `/infra/transport-xtream/README.md`
- `/AGENTS.md` - Section 4.3. 2 (Telegram Transport SSOT)
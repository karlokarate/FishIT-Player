---
applyTo:
  - core/metadata-normalizer/**
---

# Copilot Instructions: core/metadata-normalizer

> **Module Purpose:** Central normalization and TMDB enrichment. 
> This is the ONLY place where title normalization and globalId computation happens.

---

## 🔴 HARD RULES

### 1. This Module OWNS Normalization
```kotlin
// ✅ ALLOWED ONLY HERE
fun normalizeTitle(raw: String): String
fun generateGlobalId(metadata: RawMediaMetadata): String
class FallbackCanonicalKeyGenerator { ...  }
```

### 2. Deterministic Normalization
```kotlin
// Same input MUST produce same output
val result1 = normalizer.normalize(rawMetadata)
val result2 = normalizer.normalize(rawMetadata)
assert(result1 == result2)  // Always true
```

### 3. No Pipeline Dependencies
```kotlin
// ❌ FORBIDDEN
import com. fishit.player. pipeline. telegram.*  // Pipeline
import TelegramMediaItem

// ✅ CORRECT:  Only core/model
import com.fishit.player.core.model. RawMediaMetadata
```

---

## 📋 Responsibilities

| Task | This Module |
|------|-------------|
| Title normalization | ✅ Yes |
| Strip technical tags | ✅ Yes |
| Extract year/season/episode | ✅ Yes |
| Compute globalId | ✅ Yes |
| TMDB lookups | ✅ Yes (via TmdbResolver) |

---

## 📋 Key Interfaces

```kotlin
interface MediaMetadataNormalizer {
    suspend fun normalize(raw: RawMediaMetadata): NormalizedMediaMetadata
}

interface TmdbMetadataResolver {
    suspend fun enrich(metadata: NormalizedMediaMetadata): NormalizedMediaMetadata
}
```

---

## 📚 Reference Documents

- `/docs/v2/MEDIA_NORMALIZATION_CONTRACT.md` - Section 2.2, 2.3
- `/AGENTS.md` - Section 4.1
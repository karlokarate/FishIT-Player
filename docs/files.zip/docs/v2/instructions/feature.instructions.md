---
applyTo: 
  - feature/home/**
  - feature/library/**
  - feature/live/**
  - feature/detail/**
  - feature/settings/**
  - feature/telegram-media/**
  - feature/audiobooks/**
  - feature/onboarding/**
---

# Copilot Instructions: feature/*

> **Module Purpose:** User-facing feature modules. UI screens, ViewModels, 
> and feature-specific logic.  Consume domain layer, never touch transport/pipeline.

---

## 🔴 HARD RULES

### 1. Feature Modules are UI-Only
```kotlin
// ✅ ALLOWED
import androidx.compose.*
import androidx.lifecycle. ViewModel
import com.fishit.player.core.model.*
import com.fishit. player.infra.data.*      // Repositories
import com.fishit.player.playback.domain. * // Use cases

// ❌ FORBIDDEN
import com.fishit.player.pipeline.*              // Pipeline DTOs
import com. fishit.player. infra.transport.*       // Transport layer
import org.drinkless.td.*                         // TDLib
import okhttp3.*                                  // Network
```

### 2. No Pipeline DTOs in Features
```kotlin
// ❌ FORBIDDEN
fun displayItems(items: List<TelegramMediaItem>)  // Pipeline DTO
fun showVod(vod: XtreamVodItem)                   // Pipeline DTO

// ✅ CORRECT:  Use domain/model types
fun displayItems(items: List<RawMediaMetadata>)
fun showMedia(media: NormalizedMedia)
```

### 3. Use Repositories, Not Direct Data Access
```kotlin
// ❌ FORBIDDEN
@Inject lateinit var objectBox: BoxStore  // Direct persistence

// ✅ CORRECT
@Inject lateinit var mediaRepository: MediaRepository
```

### 4. Naming Convention
```kotlin
// Feature providers: *FeatureProvider
class HomeFeatureProvider :  FeatureProvider

// ViewModels: *ViewModel
class UnifiedDetailViewModel : ViewModel()

// Screens: *Screen
@Composable fun DetailScreen(...)
```

---

## 📋 Feature Module Structure

```
feature/<name>/
├── di/           # Hilt modules
├── navigation/   # Navigation setup
├── ui/           # Composables
├── viewmodel/    # ViewModels
└── <Name>FeatureProvider. kt
```

---

## 📐 Layer Position

```
Transport ← Pipeline ← Data ← Domain ← UI (Feature)
                                         ▲
                                    YOU ARE HERE
```

---

## 📚 Reference Documents

- `/contracts/GLOSSARY_v2_naming_and_modules.md` - Section 5
- `/AGENTS.md` - Section 6
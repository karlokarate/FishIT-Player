---
applyTo:
  - player/internal/**
  - player/ui/**
  - player/ui-api/**
  - player/miniplayer/**
  - playback/domain/**
  - playback/telegram/**
  - playback/xtream/**
---

# Copilot Instructions: player/* & playback/*

> **Module Purpose:** Player is SOURCE-AGNOSTIC.  It knows only `PlaybackContext` 
> and `PlaybackSourceFactory` sets.  Playback modules bridge transport to player. 

---

## 🔴 HARD RULES (from AGENTS.md Section 4.3 + Player Critical Section)

### 1. Player is SOURCE-AGNOSTIC
```kotlin
// ❌ FORBIDDEN in player/**
import com.fishit. player.infra.transport.telegram.*  // Transport
import com.fishit.player.pipeline.*                   // Pipeline
import TdlibClientProvider                            // v1 legacy! 
import TelegramTransportClient

// ✅ ALLOWED in player/**
import com.fishit.player.core.model.*
import com.fishit.player.core.playermodel.*
import com. fishit.player. playback. domain.*  // PlaybackSourceFactory
```

### 2. @Multibinds Pattern for All Sources
```kotlin
// In playback/domain - declares empty set
@Module @InstallIn(SingletonComponent::class)
abstract class PlaybackDomainModule {
    @Multibinds abstract fun bindFactories(): Set<PlaybackSourceFactory>
}

// Each source contributes via @IntoSet
// playback/telegram: 
@Binds @IntoSet abstract fun bindTelegram(impl: TelegramPlaybackSourceFactoryImpl): PlaybackSourceFactory

// playback/xtream:
@Binds @IntoSet abstract fun bindXtream(impl: XtreamPlaybackSourceFactoryImpl): PlaybackSourceFactory
```

### 3. Player Must Work With ZERO Factories
```kotlin
// ✅ Player compiles and runs without any transport
// Uses fallback stream (Big Buck Bunny) for testing
class PlaybackSourceResolver(
    private val factories: Set<PlaybackSourceFactory>  // Can be empty! 
) {
    fun resolve(context: PlaybackContext): MediaSource {
        return factories.firstOrNull { it.supports(context) }?.create(context)
            ?: createFallbackStream()  // Big Buck Bunny
    }
}
```

### 4. DataSources Belong in playback/*, NOT player/*
```kotlin
// ❌ FORBIDDEN in player/internal
class TelegramFileDataSource { ... }  // WRONG location

// ✅ CORRECT location
// playback/telegram/TelegramFileDataSource. kt
class TelegramFileDataSource(
    private val fileClient: TelegramFileClient  // Transport interface
) : DataSource { ... }
```

### 5. Player Does NOT Handle Profiles/Kids Filtering
```kotlin
// ❌ FORBIDDEN in player/**
if (profile.isKid) { filterContent() }  // WRONG - Domain's job

// ✅ CORRECT:  Domain provides pre-gated PlaybackContext
// Player just plays whatever it receives
```

---

## 📋 Player Hard Rules Summary (P-HR)

| Rule | Description |
|------|-------------|
| P-HR1 | Player MUST NOT import `pipeline/**` or `data/**` |
| P-HR2 | `core/player-model` contains ONLY primitives |
| P-HR3 | Input handling in `player/input`, NOT UI or Transport |
| P-HR4 | Player stateless re:  profiles - Domain provides these |
| P-HR5 | DataSources in `playback/*`, NOT `player/internal` |
| P-HR6 | No Kids/Guest filtering in Player - Domain does it |

---

## 📋 Module Status

| Module | Status |
|--------|--------|
| `playback/domain` | ✅ Ready - base contracts |
| `playback/telegram` | ⏸️ Disabled - waiting for typed interfaces |
| `playback/xtream` | ✅ Ready |
| `playback/local` | 🔮 Future |
| `playback/audiobook` | 🔮 Future |

---

## 📚 Reference Documents

- `/AGENTS.md` - Critical Section:  Player Layer Isolation
- `/contracts/INTERNAL_PLAYER_BEHAVIOR_CONTRACT.md`
- `/contracts/INTERNAL_PLAYER_*` - All phase contracts
- `/docs/v2/internal-player/` - All player docs
- `/playback/domain/README.md`
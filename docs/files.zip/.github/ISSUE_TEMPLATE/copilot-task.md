---
name:  Copilot Task
about: Task for Copilot Coding Agent
labels: copilot-task
---

## Task Description
<!-- Clear, specific description -->

## Affected Modules
<!-- Which v2 modules will be changed? -->
- [ ] `pipeline/telegram`
- [ ] `pipeline/xtream`
- [ ] `infra/transport-*`
- [ ] `player/*`
- [ ] `feature/*`
- [ ] Other:  ___

## Contracts to Follow
<!-- Which contracts apply? -->
- [ ] `MEDIA_NORMALIZATION_CONTRACT. md`
- [ ] `INTERNAL_PLAYER_*` contracts
- [ ] `LOGGING_CONTRACT_V2.md`
- [ ] `GLOSSARY_v2_naming_and_modules.md`

## Acceptance Criteria
- [ ] Code compiles
- [ ] Layer boundaries respected
- [ ] Tests added/updated
- [ ] No v1 namespace imports

## @copilot Instructions
<!-- Specific instructions for the agent -->
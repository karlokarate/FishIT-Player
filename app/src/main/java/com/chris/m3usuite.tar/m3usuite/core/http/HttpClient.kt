package com.chris.m3usuite.core.http

import android.content.Context
import com.chris.m3usuite.prefs.SettingsStore
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * HttpClientFactory – ohne zusätzliche Abhängigkeiten.
 *
 * Änderungen:
 * - **Kein** HttpLoggingInterceptor (kein neues Gradle-Dependency nötig).
 * - Einheitlicher Header-Injector + TrafficLogger.
 * - 5xx-Retry mit einfacher Backoff-Schleife (max 2 Versuche).
 */
object HttpClientFactory {
    @Volatile private var client: OkHttpClient? = null
    @Volatile private var cookieJar: PersistentCookieJar? = null

    fun create(context: Context, settings: SettingsStore): OkHttpClient {
        client?.let { return it }

        // Seed headers synchron (für Aufrufer ohne Lifecycle-Scope)
        val seeded = RequestHeadersProvider.ensureSeededBlocking(settings)
        val jar = PersistentCookieJar.get(context).also { cookieJar = it }

        val built = OkHttpClient.Builder()
            .cookieJar(jar)
            .connectTimeout(120, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .followRedirects(true)
            .retryOnConnectionFailure(true)
            // --- 5xx-Retry (2 Wiederholungen) ---
            .addInterceptor { chain ->
                var attempt = 0
                val maxRetries = 2
                var backoffMs = 500L
                val req0 = chain.request()
                var res = chain.proceed(req0)
                while (attempt < maxRetries && res.code in 500..599) {
                    try { res.close() } catch (_: Throwable) {}
                    try { Thread.sleep(backoffMs) } catch (_: InterruptedException) {}
                    backoffMs = (backoffMs * 1.5).toLong().coerceAtLeast(1L)
                    attempt++
                    res = chain.proceed(req0)
                }
                res
            }
            // --- Header & Traffic-Log ---
            .addInterceptor { chain ->
                val dynamic = RequestHeadersProvider.snapshot().ifEmpty { seeded }
                val inReq = chain.request()
                val nb = inReq.newBuilder()
                    .header("Accept", "*/*")
                    .header("Accept-Encoding", "gzip")
                for ((k, v) in dynamic) nb.header(k, v)
                val outReq = nb.build()
                val start = System.nanoTime()
                val res = chain.proceed(outReq)
                TrafficLogger.tryLog(appContext = context, request = outReq, response = res, startedNs = start)
                res
            }
            .build()

        client = built
        return built
    }
}

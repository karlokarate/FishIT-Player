package com.chris.m3usuite.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.asFlow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.chris.m3usuite.core.xtream.ProviderLabelStore
import com.chris.m3usuite.data.obx.toMediaItem
import com.chris.m3usuite.model.MediaItem
import com.chris.m3usuite.prefs.SettingsStore
import com.chris.m3usuite.ui.home.HomeChromeScaffold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ContentTab { Live, Vod, Series }

@Composable
private fun rememberSelectedTab(store: SettingsStore): ContentTab {
    val tabIdx by store.libraryTabIndex.collectAsStateWithLifecycle(initialValue = 0)
    return when (tabIdx) {
        0 -> ContentTab.Live
        1 -> ContentTab.Vod
        else -> ContentTab.Series
    }
}

private data class GroupKeys(
    val providers: List<String> = emptyList(),
    val genres: List<String> = emptyList(),
    val years: List<Int> = emptyList()
)

@Composable
fun LibraryScreen(
    navController: NavHostController,
    openLive: (Long) -> Unit,
    openVod: (Long) -> Unit,
    openSeries: (Long) -> Unit
) {
    val ctx = LocalContext.current
    val store = remember { SettingsStore(ctx) }
    val repo = remember { com.chris.m3usuite.data.repo.XtreamObxRepository(ctx, store) }
    val permRepo = remember { com.chris.m3usuite.data.repo.PermissionRepository(ctx, store) }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val wm = remember { WorkManager.getInstance(ctx) }

    // Tab-Auswahl synchron zur Start-Optik (BottomPanel)
    val selectedTab = rememberSelectedTab(store)

    // Rechte (Whitelist-Editing)
    var canEditWhitelist by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { canEditWhitelist = permRepo.current().canEditWhitelist }

    // Suche
    var query by remember { mutableStateOf(TextFieldValue("")) }

    // Suchtreffer (nur für aktiven Tab)
    var searchResults by remember { mutableStateOf<List<MediaItem>>(emptyList()) }

    // Gruppenschlüssel (nur für aktiven Tab, wenn keine Suche aktiv)
    var groupKeys by remember { mutableStateOf(GroupKeys()) }

    // Caches für Gruppeninhalte je sichtbarem Tab
    val providerCache = remember { mutableStateMapOf<String, List<MediaItem>>() }
    val genreCache = remember { mutableStateMapOf<String, List<MediaItem>>() }
    val yearCache = remember { mutableStateMapOf<Int, List<MediaItem>>() }

    // Helper: Laden flacher Treffer (Suche)
    suspend fun loadFlat(tab: ContentTab, q: String): List<MediaItem> = withContext(Dispatchers.IO) {
        when (tab) {
            ContentTab.Live -> {
                val rows = if (q.isNotBlank()) repo.searchLiveByName(q.trim(), 0, 240) else repo.livePaged(0, 240)
                rows.map { it.toMediaItem(ctx) }
            }
            ContentTab.Vod -> {
                val rows = if (q.isNotBlank()) repo.searchVodByName(q.trim(), 0, 240) else repo.vodPaged(0, 240)
                rows.map { it.toMediaItem(ctx) }
            }
            ContentTab.Series -> {
                val rows = if (q.isNotBlank()) repo.searchSeriesByName(q.trim(), 0, 240) else repo.seriesPaged(0, 240)
                rows.map { it.toMediaItem(ctx) }
            }
        }
    }

    // Helper: Gruppenschlüssel für aktiven Tab laden (nur ohne Suche)
    suspend fun loadGroupKeys(tab: ContentTab): GroupKeys = withContext(Dispatchers.IO) {
        when (tab) {
            ContentTab.Live -> GroupKeys(
                providers = repo.liveProviderKeys(),
                genres = repo.liveGenreKeys()
            )
            ContentTab.Vod -> GroupKeys(
                providers = repo.vodProviderKeys(),
                genres = repo.vodGenreKeys(),
                years = repo.vodYearKeys()
            )
            ContentTab.Series -> GroupKeys(
                providers = repo.seriesProviderKeys(),
                genres = repo.seriesGenreKeys(),
                years = repo.seriesYearKeys()
            )
        }
    }

    // Helper: Items für einen Gruppenschlüssel laden (mit Cache)
    suspend fun loadItemsForProvider(tab: ContentTab, key: String): List<MediaItem> = withContext(Dispatchers.IO) {
        providerCache[key] ?: run {
            val items = when (tab) {
                ContentTab.Live -> repo.liveByProviderKeyPaged(key, 0, 120).map { it.toMediaItem(ctx) }
                ContentTab.Vod -> repo.vodByProviderKeyPaged(key, 0, 120).map { it.toMediaItem(ctx) }
                ContentTab.Series -> repo.seriesByProviderKeyPaged(key, 0, 120).map { it.toMediaItem(ctx) }
            }
            providerCache[key] = items
            items
        }
    }

    suspend fun loadItemsForGenre(tab: ContentTab, key: String): List<MediaItem> = withContext(Dispatchers.IO) {
        genreCache[key] ?: run {
            val items = when (tab) {
                ContentTab.Live -> repo.liveByGenreKeyPaged(key, 0, 120).map { it.toMediaItem(ctx) }
                ContentTab.Vod -> repo.vodByGenreKeyPaged(key, 0, 120).map { it.toMediaItem(ctx) }
                ContentTab.Series -> repo.seriesByGenreKeyPaged(key, 0, 120).map { it.toMediaItem(ctx) }
            }
            genreCache[key] = items
            items
        }
    }

    suspend fun loadItemsForYear(tab: ContentTab, y: Int): List<MediaItem> = withContext(Dispatchers.IO) {
        yearCache[y] ?: run {
            val items = when (tab) {
                ContentTab.Vod -> repo.vodByYearKeyPaged(y, 0, 120).map { it.toMediaItem(ctx) }
                ContentTab.Series -> repo.seriesByYearKeyPaged(y, 0, 120).map { it.toMediaItem(ctx) }
                ContentTab.Live -> emptyList()
            }
            yearCache[y] = items
            items
        }
    }

    // (Re)Load bei Tab- oder Suchwechsel
    LaunchedEffect(selectedTab, query.text) {
        // Bei jedem Wechsel Caches für die Sicht entkoppeln (nur Memory – bei Bedarf bleiben alte Keys erhalten)
        providerCache.clear(); genreCache.clear(); yearCache.clear()

        if (query.text.isBlank()) {
            searchResults = emptyList()
            groupKeys = loadGroupKeys(selectedTab)
        } else {
            groupKeys = GroupKeys() // keine Gruppenansicht im Suchmodus
            searchResults = loadFlat(selectedTab, query.text)
        }
    }

    // OBX-Änderungen live spiegeln (nur relevanten Bereich aktualisieren)
    LaunchedEffect(Unit) {
        // Live
        launch {
            repo.liveChanges().collect {
                if (selectedTab == ContentTab.Live) {
                    if (query.text.isBlank()) groupKeys = loadGroupKeys(ContentTab.Live)
                    else searchResults = loadFlat(ContentTab.Live, query.text)
                    providerCache.clear(); genreCache.clear()
                }
            }
        }
        // Vod
        launch {
            repo.vodChanges().collect {
                if (selectedTab == ContentTab.Vod) {
                    if (query.text.isBlank()) groupKeys = loadGroupKeys(ContentTab.Vod)
                    else searchResults = loadFlat(ContentTab.Vod, query.text)
                    providerCache.clear(); genreCache.clear(); yearCache.clear()
                }
            }
        }
        // Series
        launch {
            repo.seriesChanges().collect {
                if (selectedTab == ContentTab.Series) {
                    if (query.text.isBlank()) groupKeys = loadGroupKeys(ContentTab.Series)
                    else searchResults = loadFlat(ContentTab.Series, query.text)
                    providerCache.clear(); genreCache.clear(); yearCache.clear()
                }
            }
        }
    }

    // Delta-Import-Resultat (WorkManager) ohne Polling beobachten
    LaunchedEffect(Unit) {
        wm.getWorkInfosForUniqueWorkLiveData("xtream_delta_import_once")
            .asFlow()
            .collect { infos ->
                val done = infos.any { it.state == WorkInfo.State.SUCCEEDED }
                if (done) {
                    if (query.text.isBlank()) groupKeys = loadGroupKeys(selectedTab)
                    else searchResults = loadFlat(selectedTab, query.text)
                    providerCache.clear(); genreCache.clear(); yearCache.clear()
                }
            }
    }

    // Routing-Handler je Tab
    val onOpen: (MediaItem) -> Unit = when (selectedTab) {
        ContentTab.Live -> { m -> openLive(m.id) }
        ContentTab.Vod -> { m -> openVod(m.id) }
        ContentTab.Series -> { m -> openSeries(m.id) }
    }
    val onPlay: (MediaItem) -> Unit = onOpen // hier identisch: Delegation an Details/Player

    // Kid-Whitelist-Zuweisung (nur Vod/Series)
    val onAssignVod: (MediaItem) -> Unit = remember(canEditWhitelist) {
        { mi ->
            if (!canEditWhitelist) return@remember
            scope.launch(Dispatchers.IO) {
                val kids = com.chris.m3usuite.data.repo.ProfileObxRepository(ctx).all().filter { it.type == "kid" }
                val kRepo = com.chris.m3usuite.data.repo.KidContentRepository(ctx)
                kids.forEach { kRepo.allow(it.id, "vod", mi.id) }
            }
        }
    }
    val onAssignSeries: (MediaItem) -> Unit = remember(canEditWhitelist) {
        { mi ->
            if (!canEditWhitelist) return@remember
            scope.launch(Dispatchers.IO) {
                val kids = com.chris.m3usuite.data.repo.ProfileObxRepository(ctx).all().filter { it.type == "kid" }
                val kRepo = com.chris.m3usuite.data.repo.KidContentRepository(ctx)
                kids.forEach { kRepo.allow(it.id, "series", mi.id) }
            }
        }
    }

    HomeChromeScaffold(
        title = "Bibliothek",
        onSettings = null,
        onSearch = null,
        onProfiles = null,
        onRefresh = null,
        listState = listState,
        onLogo = {
            val current = navController.currentBackStackEntry?.destination?.route
            if (current != "library") {
                navController.navigate("library") { launchSingleTop = true }
            }
        },
        bottomBar = {
            com.chris.m3usuite.ui.home.header.FishITBottomPanel(
                selected = when (selectedTab) {
                    ContentTab.Live -> "live"
                    ContentTab.Vod -> "vod"
                    ContentTab.Series -> "series"
                },
                onSelect = { sel ->
                    val idx = when (sel) { "live" -> 0; "vod" -> 1; else -> 2 }
                    scope.launch { store.setLibraryTabIndex(idx) }
                }
            )
        }
    ) { pads ->
        // identische Optik wie Start/Settings: Fish-Background + Paddings
        Box(Modifier.fillMaxSize()) {
            com.chris.m3usuite.ui.fx.FishBackground(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(32.dp),
                alpha = 0.06f
            )
        }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(vertical = 12.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(pads)
        ) {
            // Sucheingabe
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Suche (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(4.dp))
                }
            }

            // Suchergebnisse (ein Row pro aktivem Tab)
            if (query.text.isNotBlank() && searchResults.isNotEmpty()) {
                item {
                    Text(
                        when (selectedTab) {
                            ContentTab.Live -> "Live – Suchtreffer"
                            ContentTab.Vod -> "Filme – Suchtreffer"
                            ContentTab.Series -> "Serien – Suchtreffer"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
                item {
                    MediaRowForTab(
                        tab = selectedTab,
                        items = searchResults,
                        onOpenDetails = onOpen,
                        onPlayDirect = onPlay,
                        onAssignToKid = when (selectedTab) {
                            ContentTab.Vod -> onAssignVod
                            ContentTab.Series -> onAssignSeries
                            ContentTab.Live -> null
                        },
                        showAssign = canEditWhitelist && selectedTab != ContentTab.Live
                    )
                }
            }

            // Gruppenansichten (nur wenn keine Suche aktiv)
            if (query.text.isBlank()) {
                // Provider
                if (groupKeys.providers.isNotEmpty()) {
                    item {
                        Text(
                            when (selectedTab) {
                                ContentTab.Live -> "Live – Anbieter"
                                ContentTab.Vod -> "Filme – Anbieter"
                                ContentTab.Series -> "Serien – Anbieter"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    items(groupKeys.providers, key = { it }) { key ->
                        ExpandableGroupSection(
                            tab = selectedTab,
                            groupLabel = { ProviderLabelStore.get(ctx).labelFor(key) },
                            expandedDefault = true,
                            loadItems = { loadItemsForProvider(selectedTab, key) },
                            onOpenDetails = onOpen,
                            onPlayDirect = onPlay,
                            onAssignToKid = when (selectedTab) {
                                ContentTab.Vod -> onAssignVod
                                ContentTab.Series -> onAssignSeries
                                ContentTab.Live -> null
                            },
                            showAssign = canEditWhitelist && selectedTab != ContentTab.Live
                        )
                    }
                }

                // Jahre (nur Vod/Series)
                if (groupKeys.years.isNotEmpty() && selectedTab != ContentTab.Live) {
                    item {
                        Text(
                            when (selectedTab) {
                                ContentTab.Vod -> "Filme – Jahre"
                                ContentTab.Series -> "Serien – Jahre"
                                else -> ""
                            },
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    items(groupKeys.years, key = { it }) { y ->
                        ExpandableGroupSection(
                            tab = selectedTab,
                            groupLabel = { y.toString() },
                            expandedDefault = false,
                            loadItems = { loadItemsForYear(selectedTab, y) },
                            onOpenDetails = onOpen,
                            onPlayDirect = onPlay,
                            onAssignToKid = when (selectedTab) {
                                ContentTab.Vod -> onAssignVod
                                ContentTab.Series -> onAssignSeries
                                ContentTab.Live -> null
                            },
                            showAssign = canEditWhitelist && selectedTab != ContentTab.Live
                        )
                    }
                }

                // Genres
                if (groupKeys.genres.isNotEmpty()) {
                    item {
                        Text(
                            when (selectedTab) {
                                ContentTab.Live -> "Live – Genres"
                                ContentTab.Vod -> "Filme – Genres"
                                ContentTab.Series -> "Serien – Genres"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    items(groupKeys.genres, key = { it }) { key ->
                        ExpandableGroupSection(
                            tab = selectedTab,
                            groupLabel = {
                                // Einheitlicher Fallback für leere Genre-Keys
                                ProviderLabelStore.get(ctx).labelFor(key).ifBlank { "Unbekannt" }
                            },
                            expandedDefault = selectedTab == ContentTab.Live, // Live-Genres oft nützlicher -> optional offen
                            loadItems = { loadItemsForGenre(selectedTab, key) },
                            onOpenDetails = onOpen,
                            onPlayDirect = onPlay,
                            onAssignToKid = when (selectedTab) {
                                ContentTab.Vod -> onAssignVod
                                ContentTab.Series -> onAssignSeries
                                ContentTab.Live -> null
                            },
                            showAssign = canEditWhitelist && selectedTab != ContentTab.Live
                        )
                    }
                }
            }
        }
    }
}

/**
 * Generische, wiederverwendbare Sektion mit expand/collapse und Lazy-Loading der Items.
 * Der Row-Typ (Live/Vod/Series) wird über 'tab' bestimmt – dadurch keine doppelten UI-Bausteine.
 */
@Composable
private fun ExpandableGroupSection(
    tab: ContentTab,
    groupLabel: () -> String,
    expandedDefault: Boolean,
    loadItems: suspend () -> List<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: ((MediaItem) -> Unit)?,
    showAssign: Boolean
) {
    var expanded by remember { mutableStateOf(expandedDefault) }
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(groupLabel(), style = MaterialTheme.typography.titleSmall)
            TextButton(onClick = {
                expanded = !expanded
                if (expanded && items.isEmpty()) {
                    scope.launch { items = loadItems() }
                }
            }) {
                Text(if (expanded) "Weniger" else "Mehr")
            }
        }
        if (expanded) {
            // Erst laden, wenn geöffnet (Lazy-Loading)
            LaunchedEffect(Unit) {
                if (items.isEmpty()) items = loadItems()
            }
            MediaRowForTab(
                tab = tab,
                items = items,
                onOpenDetails = onOpenDetails,
                onPlayDirect = onPlayDirect,
                onAssignToKid = onAssignToKid,
                showAssign = showAssign
            )
        }
    }
}

@Composable
private fun MediaRowForTab(
    tab: ContentTab,
    items: List<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: ((MediaItem) -> Unit)?,
    showAssign: Boolean
) {
    when (tab) {
        ContentTab.Live -> {
            com.chris.m3usuite.ui.components.rows.LiveRow(
                items = items,
                onOpenDetails = { m -> onOpenDetails(m) },
                onPlayDirect = { m -> onPlayDirect(m) }
            )
        }
        ContentTab.Vod -> {
            com.chris.m3usuite.ui.components.rows.VodRow(
                items = items,
                onOpenDetails = { m -> onOpenDetails(m) },
                onPlayDirect = { m -> onPlayDirect(m) },
                onAssignToKid = { m -> onAssignToKid?.invoke(m) },
                showAssign = showAssign
            )
        }
        ContentTab.Series -> {
            com.chris.m3usuite.ui.components.rows.SeriesRow(
                items = items,
                onOpenDetails = { m -> onOpenDetails(m) },
                onPlayDirect = { m -> onPlayDirect(m) },
                onAssignToKid = { m -> onAssignToKid?.invoke(m) },
                showAssign = showAssign
            )
        }
    }
}

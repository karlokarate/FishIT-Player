package com.chris.m3usuite.data.obx

import android.content.Context
import com.chris.m3usuite.core.xtream.XtreamConfig
import com.chris.m3usuite.model.Episode
import com.chris.m3usuite.model.MediaItem
import com.chris.m3usuite.prefs.SettingsStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import java.util.concurrent.atomic.AtomicReference

// ---------------------------------------------------------
// Utilities
// ---------------------------------------------------------

private fun normSort(s: String): String = s.lowercase().trim()

/**
 * Lazy + cached XtreamConfig-Factory (non-suspend).
 * Liest genau einmal Host/Port/User/Pass aus dem SettingsStore (runBlocking) und cached.
 * Port→Scheme: 443→https, sonst http.
 */
private object XtreamUrlFactory {
    private val ref = AtomicReference<XtreamConfig?>()

    fun getOrNull(ctx: Context): XtreamConfig? {
        ref.get()?.let { return it }
        return runBlocking {
            val store = SettingsStore(ctx)
            val host = store.xtHost.first().trim()
            val port = store.xtPort.first()
            val user = store.xtUser.first().trim()
            val pass = store.xtPass.first().trim()
            if (host.isBlank() || user.isBlank() || pass.isBlank() || port <= 0) return@runBlocking null
            val scheme = if (port == 443) "https" else "http"
            val cfg = XtreamConfig(
                scheme = scheme,
                host = host,
                port = port,
                username = user,
                password = pass
            )
            ref.set(cfg)
            cfg
        }
    }

    fun invalidate() { ref.set(null) }
}

/** Von außen aufrufbar, z. B. nach Login/Discovery. */
fun invalidateXtreamUrlCache() = XtreamUrlFactory.invalidate()

// ---------------------------------------------------------
// Adapters: OBX → UI-Modelle
// ---------------------------------------------------------

/**
 * Live → MediaItem
 * - Baut sofort eine abspielbare Play-URL (m3u8/ts nach Präferenz von XtreamConfig)
 */
fun ObxLive.toMediaItem(ctx: Context): MediaItem {
    val encodedId = 1_000_000_000_000L + this.streamId.toLong()
    val cfg = XtreamUrlFactory.getOrNull(ctx)
    val playUrl = cfg?.liveUrl(this.streamId)
    return MediaItem(
        id = encodedId,
        type = "live",
        streamId = this.streamId,
        name = this.name,
        sortTitle = normSort(this.name),
        categoryId = this.categoryId,
        categoryName = null,
        logo = this.logo,
        poster = this.logo,
        backdrop = null,
        epgChannelId = this.epgChannelId,
        year = null,
        rating = null,
        durationSecs = null,
        plot = null,
        url = playUrl, // entscheidend: abspielbar
        extraJson = null,
        source = "XTREAM"
    )
}

/**
 * VOD → MediaItem
 * - Nutzt vorhandene Container-Endung (z. B. "mp4") für die Play-URL
 * - Images werden aus JSON übernommen
 */
fun ObxVod.toMediaItem(ctx: Context): MediaItem {
    val encodedId = 2_000_000_000_000L + this.vodId.toLong()
    val images: List<String> = runCatching {
        this.imagesJson?.let { j ->
            Json.parseToJsonElement(j).jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }
        }
    }.getOrNull() ?: emptyList()

    val cfg = XtreamUrlFactory.getOrNull(ctx)
    val playUrl = cfg?.vodUrl(this.vodId, this.containerExt)

    return MediaItem(
        id = encodedId,
        type = "vod",
        streamId = this.vodId,
        name = this.name,
        sortTitle = normSort(this.name),
        categoryId = this.categoryId,
        categoryName = null,
        logo = this.poster,
        poster = this.poster,
        backdrop = null,
        epgChannelId = null,
        year = this.year,
        rating = this.rating,
        durationSecs = null,
        plot = this.plot,
        url = playUrl, // entscheidend: abspielbar
        extraJson = null,
        source = "XTREAM",
        images = images,
        imdbId = this.imdbId,
        tmdbId = this.tmdbId,
        trailer = this.trailer,
        director = this.director,
        cast = this.cast,
        country = this.country,
        releaseDate = this.releaseDate,
        genre = this.genre,
        containerExt = this.containerExt
    )
}

/**
 * Series → MediaItem
 * - Serien haben keine direkte Play-URL (die hängt von Staffel/Episode ab)
 * - Poster/Backdrops aus Images-JSON (falls vorhanden)
 */
fun ObxSeries.toMediaItem(ctx: Context): MediaItem {
    val encodedId = 3_000_000_000_000L + this.seriesId.toLong()
    val images: List<String> = runCatching {
        this.imagesJson?.let { j ->
            Json.parseToJsonElement(j).jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }
        }
    }.getOrNull() ?: emptyList()

    return MediaItem(
        id = encodedId,
        type = "series",
        streamId = this.seriesId,
        name = this.name,
        sortTitle = normSort(this.name),
        categoryId = this.categoryId,
        categoryName = null,
        logo = null,
        poster = images.firstOrNull(),
        backdrop = images.drop(1).firstOrNull(),
        epgChannelId = null,
        year = this.year,
        rating = this.rating,
        durationSecs = null,
        plot = this.plot,
        url = null, // bewusst: Episode-URL erst bei Auswahl
        extraJson = null,
        source = "XTREAM",
        images = images,
        imdbId = this.imdbId,
        tmdbId = this.tmdbId,
        trailer = this.trailer,
        director = this.director,
        cast = this.cast,
        genre = this.genre
    )
}

/**
 * Episode (OBX) → UI Episode
 * - Beinhaltet containerExt, damit die UI später gezielt die Episode-URL bauen kann
 * - Optionaler Helper (siehe unten) zum direkten Play-URL-Bauen
 */
fun ObxEpisode.toEpisode(): Episode = Episode(
    // id bleibt 0L – Episoden sind in OBX über (seriesId, season, episodeNum) identifizierbar
    seriesStreamId = this.seriesId,
    season = this.season,
    episodeNum = this.episodeNum,
    title = this.title,
    plot = this.plot,
    durationSecs = this.durationSecs,
    rating = this.rating,
    airDate = this.airDate,
    containerExt = this.playExt
)

// ---------------------------------------------------------
// Optional Helpers: Episode-Play-URL
// ---------------------------------------------------------

/**
 * Baut eine direkte Play-URL für eine Episode (falls gewünscht).
 * Falls keine Xtream-Creds konfiguriert sind, gibt null zurück.
 */
fun buildEpisodePlayUrl(
    ctx: Context,
    seriesStreamId: Int,
    season: Int,
    episodeNum: Int,
    episodeExt: String?
): String? {
    val cfg = XtreamUrlFactory.getOrNull(ctx) ?: return null
    return cfg.seriesEpisodeUrl(seriesStreamId, season, episodeNum, episodeExt)
}

/** Bequemer Overload direkt aus einem Episode-Objekt. */
fun Episode.buildPlayUrl(ctx: Context): String? =
    buildEpisodePlayUrl(ctx, seriesStreamId, season, episodeNum, containerExt)

package com.chris.m3usuite.data.repo

import android.content.Context
import com.chris.m3usuite.core.http.HttpClientFactory
import com.chris.m3usuite.core.xtream.*
import com.chris.m3usuite.data.obx.*
import com.chris.m3usuite.prefs.SettingsStore
import io.objectbox.kotlin.boxFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.coroutines.flow.first
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import io.objectbox.query.QueryBuilder
import io.objectbox.Box
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import io.objectbox.android.AndroidScheduler
import kotlin.math.min

class XtreamObxRepository(
    private val context: Context,
    private val settings: SettingsStore
) {
    private fun normalizeProvider(categoryName: String?, fallbackFromName: String?): String? {
        // Use UI normalizer to keep grouping consistent
        val key = com.chris.m3usuite.core.util.CategoryNormalizer.normalizeKey(categoryName ?: fallbackFromName)
        // Learn display label dynamically from API-provided category/name
        runCatching { com.chris.m3usuite.core.xtream.ProviderLabelStore.get(context).learn(key, categoryName ?: fallbackFromName) }
        return key
    }

    // ---------------------
    // ObjectBox -> Compose change signals
    // ---------------------
    fun liveChanges(): Flow<Unit> = callbackFlow {
        val box = ObxStore.get(context).boxFor<ObxLive>()
        val q = box.query().build()
        // initial signal (current state)
        trySend(Unit).isSuccess
        val sub = q.subscribe().on(AndroidScheduler.mainThread()).observer { trySend(Unit).isSuccess }
        awaitClose { sub.cancel() }
    }

    fun vodChanges(): Flow<Unit> = callbackFlow {
        val box = ObxStore.get(context).boxFor<ObxVod>()
        val q = box.query().build()
        trySend(Unit).isSuccess
        val sub = q.subscribe().on(AndroidScheduler.mainThread()).observer { trySend(Unit).isSuccess }
        awaitClose { sub.cancel() }
    }

    fun seriesChanges(): Flow<Unit> = callbackFlow {
        val box = ObxStore.get(context).boxFor<ObxSeries>()
        val q = box.query().build()
        trySend(Unit).isSuccess
        val sub = q.subscribe().on(AndroidScheduler.mainThread()).observer { trySend(Unit).isSuccess }
        awaitClose { sub.cancel() }
    }

    /**
     * Quick seeding of initial content for immediate UI visibility.
     * Fetches a bounded number of items per kind (no details) and upserts into OBX.
     * Does NOT delete orphans and avoids heavy detail fetches.
     */
    suspend fun seedListsQuick(limitPerKind: Int = 200, forceRefreshDiscovery: Boolean = false): Result<Triple<Int, Int, Int>> = withContext(Dispatchers.IO) {
        runCatching {
            val client = newClient(forceRefreshDiscovery)
            val boxStore = ObxStore.get(context)
            val catBox = boxStore.boxFor<ObxCategory>()
            val liveBox = boxStore.boxFor<ObxLive>()
            val vodBox = boxStore.boxFor<ObxVod>()
            val seriesBox = boxStore.boxFor<ObxSeries>()

            // Kategorien: nur upserten (keine Löschungen, um Flackern zu vermeiden)
            run {
                val liveCats = client.getLiveCategories(); val vodCats = client.getVodCategories(); val serCats = client.getSeriesCategories()
                upsertCategories(catBox, "live", liveCats.associate { it.category_id.orEmpty() to it.category_name.orEmpty() }, deleteOrphans = false)
                upsertCategories(catBox, "vod",  vodCats.associate  { it.category_id.orEmpty() to it.category_name.orEmpty() }, deleteOrphans = false)
                upsertCategories(catBox, "series", serCats.associate { it.category_id.orEmpty() to it.category_name.orEmpty() }, deleteOrphans = false)
            }

            var liveCount = 0; var vodCount = 0; var seriesCount = 0

            // Live (first N only) – batch put
            run {
                val toPut = mutableListOf<ObxLive>()
                val liveList = client.getLiveStreams(categoryId = null, offset = 0, limit = limitPerKind)
                val liveCats = catBox.query(ObxCategory_.kind.equal("live")).build().find().associateBy({ it.categoryId }, { it.categoryName })
                liveList.forEach { r ->
                    val sid = r.stream_id ?: return@forEach
                    val existing = liveBox.query(ObxLive_.streamId.equal(sid.toLong())).build().findFirst()
                    val catName = liveCats[r.category_id.orEmpty()]
                    val provider = normalizeProvider(catName, r.name)
                    val gKey = deriveGenreKey(r.name, catName, null)
                    val entity = ObxLive(
                        streamId = sid,
                        nameLower = r.name.orEmpty().lowercase(),
                        sortTitleLower = sortKey(r.name),
                        name = r.name.orEmpty(),
                        logo = r.stream_icon,
                        epgChannelId = r.epg_channel_id,
                        tvArchive = r.tv_archive,
                        categoryId = r.category_id,
                        providerKey = provider,
                        genreKey = gKey
                    )
                    if (existing != null) entity.id = existing.id
                    toPut += entity
                }
                if (toPut.isNotEmpty()) liveBox.putChunked(toPut, 2000)
                liveCount = toPut.size
            }

            // VOD (first N only, no details) – batch put
            run {
                val vodCats = catBox.query(ObxCategory_.kind.equal("vod")).build().find().associateBy({ it.categoryId }, { it.categoryName })
                val list = client.getVodStreams(categoryId = null, offset = 0, limit = limitPerKind)
                val toPut = mutableListOf<ObxVod>()
                list.forEach { r ->
                    val vid = r.vod_id ?: return@forEach
                    val existing = vodBox.query(ObxVod_.vodId.equal(vid.toLong())).build().findFirst()
                    val nameLower = r.name.orEmpty().lowercase()
                    val catName = vodCats[r.category_id.orEmpty()]
                    val provider = normalizeProvider(catName, r.name)
                    val entity = if (existing == null) ObxVod(
                        vodId = vid,
                        nameLower = nameLower,
                        sortTitleLower = sortKey(r.name),
                        name = r.name.orEmpty(),
                        poster = r.stream_icon,
                        categoryId = r.category_id,
                        providerKey = provider
                    ) else existing.copy(
                        nameLower = nameLower,
                        sortTitleLower = sortKey(r.name),
                        categoryId = r.category_id,
                        providerKey = provider
                    )
                    toPut += entity
                }
                if (toPut.isNotEmpty()) vodBox.putChunked(toPut, 2000)
                vodCount = toPut.size
            }

            // Series (first N only, no details) – batch put
            run {
                val serCats = catBox.query(ObxCategory_.kind.equal("series")).build().find().associateBy({ it.categoryId }, { it.categoryName })
                val list = client.getSeries(categoryId = null, offset = 0, limit = limitPerKind)
                val toPut = mutableListOf<ObxSeries>()
                list.forEach { r ->
                    val sid = r.series_id ?: return@forEach
                    val existing = seriesBox.query(ObxSeries_.seriesId.equal(sid.toLong())).build().findFirst()
                    val nameLower = r.name.orEmpty().lowercase()
                    val catName = serCats[r.category_id.orEmpty()]
                    val provider = normalizeProvider(catName, r.name)
                    val entity = if (existing == null) ObxSeries(
                        seriesId = sid,
                        nameLower = nameLower,
                        sortTitleLower = sortKey(r.name),
                        name = r.name.orEmpty(),
                        categoryId = r.category_id,
                        providerKey = provider
                    ) else existing.copy(
                        nameLower = nameLower,
                        sortTitleLower = sortKey(r.name),
                        categoryId = r.category_id,
                        providerKey = provider
                    )
                    toPut += entity
                }
                if (toPut.isNotEmpty()) seriesBox.putChunked(toPut, 2000)
                seriesCount = toPut.size
            }

            Triple(liveCount, vodCount, seriesCount)
        }
    }

    /**
     * On-demand import of a single series details + episodes into ObjectBox.
     * Upserts ObxSeries and replaces episodes for the given seriesId.
     */
    suspend fun importSeriesDetailOnce(seriesId: Int): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val client = newClient()
            val boxStore = ObxStore.get(context)
            val serBox = boxStore.boxFor<ObxSeries>()
            val epBox = boxStore.boxFor<ObxEpisode>()

            val d = client.getSeriesDetailFull(seriesId) ?: return@runCatching 0
            val images = d.images ?: emptyList()
            val sEntity = ObxSeries(
                seriesId = seriesId,
                nameLower = (d.name ?: "").lowercase(),
                sortTitleLower = sortKey(d.name),
                name = d.name ?: "",
                imagesJson = runCatching { Json.encodeToString(ListSerializer(String.serializer()), images) }.getOrNull(),
                year = d.year,
                yearKey = deriveYearKeyInt(d.year, d.name),
                rating = d.rating,
                plot = d.plot,
                genre = d.genre,
                director = d.director,
                cast = d.cast,
                imdbId = d.imdbId,
                tmdbId = d.tmdbId,
                trailer = d.trailer,
                categoryId = null,
                providerKey = null,
                genreKey = deriveGenreKey(d.name, null, d.genre)
            )
            // Preserve existing row id if present
            serBox.query(ObxSeries_.seriesId.equal(seriesId.toLong())).build().findFirst()?.let { sEntity.id = it.id }
            serBox.put(sEntity)

            // Replace episodes for this series (chunked put)
            val existing = epBox.query(ObxEpisode_.seriesId.equal(seriesId.toLong())).build().find()
            if (existing.isNotEmpty()) epBox.remove(existing)
            val episodes = mutableListOf<ObxEpisode>()
            d.seasons.forEach { s ->
                s.episodes.forEach { e ->
                    episodes += ObxEpisode(
                        seriesId = seriesId,
                        season = s.seasonNumber,
                        episodeNum = e.episodeNum,
                        title = e.title,
                        durationSecs = e.durationSecs,
                        rating = e.rating,
                        plot = e.plot,
                        airDate = e.airDate,
                        playExt = e.playExt
                    )
                }
            }
            if (episodes.isNotEmpty()) epBox.putChunked(episodes, 2000)
            episodes.size
        }
    }

    private fun deriveGenreKey(name: String?, categoryName: String?, explicitGenre: String? = null): String? {
        val s = listOfNotNull(explicitGenre, categoryName, name).joinToString(" ").lowercase()
        return when {
            s.contains("sport") -> "sport"
            s.contains("news") || s.contains("nachricht") -> "news"
            s.contains("doku") || s.contains("docu") || s.contains("dokument") || s.contains("documentary") -> "doku"
            s.contains("kids") || s.contains("kinder") || s.contains("family") || s.contains("familie") -> "kids"
            s.contains("comedy") || s.contains("komö") || s.contains("komed") -> "comedy"
            s.contains("sci-fi") || s.contains("science fiction") || s.contains("scifi") -> "sci_fi"
            s.contains("drama") -> "drama"
            s.contains("musik") || s.contains("music") -> "musik"
            s.contains("film") || s.contains("movie") -> "film"
            s.contains("serie") || s.contains("series") -> "serie"
            else -> null
        }
    }

    /**
     * Delta import (upsert) for large datasets. Avoids full clears and fetches details only for new/changed items.
     * Returns counts Triple(live, vod, series) processed.
     */
    suspend fun importDelta(deleteOrphans: Boolean = true): Result<Triple<Int, Int, Int>> = withContext(Dispatchers.IO) {
        runCatching {
            val client = newClient()
            val boxStore = ObxStore.get(context)
            val catBox = boxStore.boxFor<ObxCategory>()
            val liveBox = boxStore.boxFor<ObxLive>()
            val vodBox = boxStore.boxFor<ObxVod>()
            val seriesBox = boxStore.boxFor<ObxSeries>()

            // Kategorien: Diff (Upsert + optionales Löschen verwaister Kategorien)
            run {
                val liveCats = client.getLiveCategories(); val vodCats = client.getVodCategories(); val serCats = client.getSeriesCategories()
                upsertCategories(catBox, "live", liveCats.associate { it.category_id.orEmpty() to it.category_name.orEmpty() }, deleteOrphans = deleteOrphans)
                upsertCategories(catBox, "vod",  vodCats.associate  { it.category_id.orEmpty() to it.category_name.orEmpty() }, deleteOrphans = deleteOrphans)
                upsertCategories(catBox, "series", serCats.associate { it.category_id.orEmpty() to it.category_name.orEmpty() }, deleteOrphans = deleteOrphans)
            }

            // --- Live (upsert by streamId, batched) ---
            val liveSeen = mutableSetOf<Int>()
            run {
                val toPut = mutableListOf<ObxLive>()
                val liveList = client.getLiveStreams(categoryId = null, offset = 0, limit = Int.MAX_VALUE)
                val liveCats = catBox.query(ObxCategory_.kind.equal("live")).build().find().associateBy({ it.categoryId }, { it.categoryName })
                liveList.forEach { r ->
                    val sid = r.stream_id ?: return@forEach
                    liveSeen += sid
                    val existing = liveBox.query(ObxLive_.streamId.equal(sid.toLong())).build().findFirst()
                    val catName = liveCats[r.category_id.orEmpty()]
                    val provider = normalizeProvider(catName, r.name)
                    val gKey = deriveGenreKey(r.name, catName, null)
                    val entity = ObxLive(
                        streamId = sid,
                        nameLower = r.name.orEmpty().lowercase(),
                        sortTitleLower = sortKey(r.name),
                        name = r.name.orEmpty(),
                        logo = r.stream_icon,
                        epgChannelId = r.epg_channel_id,
                        tvArchive = r.tv_archive,
                        categoryId = r.category_id,
                        providerKey = provider,
                        genreKey = gKey
                    )
                    if (existing != null) entity.id = existing.id
                    toPut += entity
                }
                if (toPut.isNotEmpty()) liveBox.putChunked(toPut, 2000)

                if (deleteOrphans && liveSeen.isNotEmpty()) {
                    val all = liveBox.all
                    val toRemove = all.filter { it.streamId !in liveSeen }
                    if (toRemove.isNotEmpty()) liveBox.remove(toRemove)
                }
            }

            // --- VOD (upsert; details only for new/changed; batched) ---
            val vodSeen = mutableSetOf<Int>()
            run {
                val updates = mutableListOf<ObxVod>()
                val vodCats = catBox.query(ObxCategory_.kind.equal("vod")).build().find().associateBy({ it.categoryId }, { it.categoryName })
                val list = client.getVodStreams(categoryId = null, offset = 0, limit = Int.MAX_VALUE)
                val toDetail = mutableListOf<Int>()
                list.forEach { r ->
                    val vid = r.vod_id ?: return@forEach
                    vodSeen += vid
                    val existing = vodBox.query(ObxVod_.vodId.equal(vid.toLong())).build().findFirst()
                    val nameLower = r.name.orEmpty().lowercase()
                    val catId = r.category_id
                    val needsDetail = existing == null || existing.nameLower != nameLower || existing.categoryId != catId
                    if (needsDetail) toDetail += vid
                    else {
                        val catName = vodCats[catId.orEmpty()]
                        val provider = normalizeProvider(catName, r.name)
                        updates += existing.copy(
                            nameLower = nameLower,
                            sortTitleLower = sortKey(r.name),
                            categoryId = catId,
                            providerKey = provider
                        )
                    }
                }
                if (updates.isNotEmpty()) vodBox.putChunked(updates, 2000)

                if (toDetail.isNotEmpty()) {
                    val sem = Semaphore(6)
                    val results = coroutineScope {
                        toDetail.map { vid ->
                            async(Dispatchers.IO) {
                                sem.withPermit {
                                    val r = list.firstOrNull { it.vod_id == vid }
                                    val d = client.getVodDetailFull(vid)
                                    val images = d?.images ?: emptyList()
                                    val catName = vodCats[r?.category_id.orEmpty()]
                                    val provider = normalizeProvider(catName, d?.name ?: r?.name)
                                    val gKey = deriveGenreKey(d?.name ?: r?.name, catName, d?.genre)
                                    val y = d?.year
                                    val yKey = deriveYearKeyInt(y, d?.name ?: r?.name)
                                    val existing = vodBox.query(ObxVod_.vodId.equal(vid.toLong())).build().findFirst()
                                    val entity = ObxVod(
                                        vodId = vid,
                                        nameLower = (d?.name ?: r?.name.orEmpty()).lowercase(),
                                        sortTitleLower = sortKey(d?.name ?: r?.name),
                                        name = d?.name ?: r?.name.orEmpty(),
                                        poster = images.firstOrNull(),
                                        imagesJson = runCatching { Json.encodeToString(ListSerializer(String.serializer()), images) }.getOrNull(),
                                        year = y,
                                        yearKey = yKey,
                                        rating = d?.rating,
                                        plot = d?.plot,
                                        genre = d?.genre,
                                        director = d?.director,
                                        cast = d?.cast,
                                        country = d?.country,
                                        releaseDate = d?.releaseDate,
                                        imdbId = d?.imdbId,
                                        tmdbId = d?.tmdbId,
                                        trailer = d?.trailer,
                                        containerExt = null,
                                        categoryId = r?.category_id,
                                        providerKey = provider,
                                        genreKey = gKey
                                    )
                                    if (existing != null) entity.id = existing.id
                                    entity
                                }
                            }
                        }.awaitAll()
                    }
                    if (results.isNotEmpty()) vodBox.putChunked(results, 2000)
                }
                if (deleteOrphans && vodSeen.isNotEmpty()) {
                    val all = vodBox.all
                    val toRemove = all.filter { it.vodId !in vodSeen }
                    if (toRemove.isNotEmpty()) vodBox.remove(toRemove)
                }
            }

            // --- Series (upsert; details only for new/changed; batched) ---
            val seriesSeen = mutableSetOf<Int>()
            run {
                val updates = mutableListOf<ObxSeries>()
                val serCats = catBox.query(ObxCategory_.kind.equal("series")).build().find().associateBy({ it.categoryId }, { it.categoryName })
                val list = client.getSeries(categoryId = null, offset = 0, limit = Int.MAX_VALUE)
                val toDetail = mutableListOf<Int>()
                list.forEach { r ->
                    val sid = r.series_id ?: return@forEach
                    seriesSeen += sid
                    val existing = seriesBox.query(ObxSeries_.seriesId.equal(sid.toLong())).build().findFirst()
                    val nameLower = r.name.orEmpty().lowercase()
                    val catId = r.category_id
                    val needsDetail = existing == null || existing.nameLower != nameLower || existing.categoryId != catId
                    if (needsDetail) toDetail += sid
                    else {
                        val catName = serCats[catId.orEmpty()]
                        val provider = normalizeProvider(catName, r.name)
                        updates += existing.copy(
                            nameLower = nameLower,
                            sortTitleLower = sortKey(r.name),
                            categoryId = catId,
                            providerKey = provider
                        )
                    }
                }
                if (updates.isNotEmpty()) seriesBox.putChunked(updates, 2000)

                if (toDetail.isNotEmpty()) {
                    val sem = Semaphore(6)
                    val results = coroutineScope {
                        toDetail.map { sid ->
                            async(Dispatchers.IO) {
                                sem.withPermit {
                                    val r = list.firstOrNull { it.series_id == sid }
                                    val d = client.getSeriesDetailFull(sid)
                                    val images = d?.images ?: emptyList()
                                    val catName = serCats[r?.category_id.orEmpty()]
                                    val provider = normalizeProvider(catName, d?.name ?: r?.name)
                                    val gKey = deriveGenreKey(d?.name ?: r?.name, catName, d?.genre)
                                    val y = d?.year
                                    val yKey = deriveYearKeyInt(y, d?.name ?: r?.name)
                                    val existing = seriesBox.query(ObxSeries_.seriesId.equal(sid.toLong())).build().findFirst()
                                    val entity = ObxSeries(
                                        seriesId = sid,
                                        nameLower = (d?.name ?: r?.name.orEmpty()).lowercase(),
                                        sortTitleLower = sortKey(d?.name ?: r?.name),
                                        name = d?.name ?: r?.name.orEmpty(),
                                        imagesJson = runCatching { Json.encodeToString(ListSerializer(String.serializer()), images) }.getOrNull(),
                                        year = y,
                                        yearKey = yKey,
                                        rating = d?.rating,
                                        plot = d?.plot,
                                        genre = d?.genre,
                                        director = d?.director,
                                        cast = d?.cast,
                                        imdbId = d?.imdbId,
                                        tmdbId = d?.tmdbId,
                                        trailer = d?.trailer,
                                        categoryId = r?.category_id,
                                        providerKey = provider,
                                        genreKey = gKey
                                    )
                                    if (existing != null) entity.id = existing.id
                                    entity
                                }
                            }
                        }.awaitAll()
                    }
                    if (results.isNotEmpty()) seriesBox.putChunked(results, 2000)
                }
                if (deleteOrphans && seriesSeen.isNotEmpty()) {
                    val all = seriesBox.all
                    val toRemove = all.filter { it.seriesId !in seriesSeen }
                    if (toRemove.isNotEmpty()) seriesBox.remove(toRemove)
                }
            }

            Triple(liveSeen.size, vodSeen.size, seriesSeen.size)
        }
    }

    private fun sortKey(name: String?): String {
        val s = name.orEmpty().trim().lowercase()
        val drop = listOf("the ", "a ", "an ", "der ", "die ", "das ", "le ", "la ", "les ", "el ", "los ", "las ")
        var out = s
        drop.forEach { art -> if (out.startsWith(art)) out = out.removePrefix(art) }
        out = out.replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")
        return out
    }

    private fun deriveYearKeyInt(explicit: Int?, name: String?): Int? {
        return explicit ?: com.chris.m3usuite.domain.selectors.extractYearFrom(name)
    }
    private suspend fun newClient(forceRefreshDiscovery: Boolean = false): XtreamClient = withContext(Dispatchers.IO) {
        val http = HttpClientFactory.create(context, settings)
        val store = ProviderCapabilityStore(context)
        val portStore = EndpointPortStore(context)
        val host = settings.xtHost.first()
        val user = settings.xtUser.first()
        val pass = settings.xtPass.first()
        val port = settings.xtPort.first()
        val scheme = if (port == 443) "https" else "http"
        val client = XtreamClient(http)
        client.initialize(
            scheme = scheme,
            host = host,
            username = user,
            password = pass,
            basePath = null,
            store = store,
            portStore = portStore,
            forceRefreshDiscovery = forceRefreshDiscovery,
            portOverride = port
        )
        client
    }

    /**
     * Full import into ObjectBox: categories, live, vod (with details), series (with seasons+episodes).
     * Designed for on-demand usage (UI can be wired later).
     */
    @Deprecated("Heavy path; prefer importDelta(deleteOrphans=true) in production")
    suspend fun importAllFull(): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val client = newClient()
            val boxStore = ObxStore.get(context)
            val catBox = boxStore.boxFor<ObxCategory>()
            val liveBox = boxStore.boxFor<ObxLive>()
            val vodBox = boxStore.boxFor<ObxVod>()
            val seriesBox = boxStore.boxFor<ObxSeries>()
            val epBox = boxStore.boxFor<ObxEpisode>()

            // Categories
            val liveCats = client.getLiveCategories()
            val vodCats = client.getVodCategories()
            val serCats = client.getSeriesCategories()
            val liveCatMap = liveCats.associateBy({ it.category_id.orEmpty() }, { it.category_name })
            val vodCatMap = vodCats.associateBy({ it.category_id.orEmpty() }, { it.category_name })
            val serCatMap = serCats.associateBy({ it.category_id.orEmpty() }, { it.category_name })
            catBox.removeAll()
            catBox.put(liveCats.map { ObxCategory(kind = "live", categoryId = it.category_id.orEmpty(), categoryName = it.category_name) })
            catBox.put(vodCats.map { ObxCategory(kind = "vod", categoryId = it.category_id.orEmpty(), categoryName = it.category_name) })
            catBox.put(serCats.map { ObxCategory(kind = "series", categoryId = it.category_id.orEmpty(), categoryName = it.category_name) })

            // Live – bulk list
            val live = client.getLiveStreams(categoryId = null, offset = 0, limit = Int.MAX_VALUE)
            liveBox.removeAll()
            liveBox.put(live.mapNotNull { r ->
                val sid = r.stream_id ?: return@mapNotNull null
                val catName = liveCatMap[r.category_id.orEmpty()]
                val provider = normalizeProvider(catName, r.name)
                val genreKey = deriveGenreKey(r.name, catName, null)
                ObxLive(
                    streamId = sid,
                    nameLower = r.name.orEmpty().lowercase(),
                    sortTitleLower = sortKey(r.name),
                    name = r.name.orEmpty(),
                    logo = r.stream_icon,
                    epgChannelId = r.epg_channel_id,
                    tvArchive = r.tv_archive,
                    categoryId = r.category_id,
                    providerKey = provider,
                    genreKey = genreKey
                )
            })

            // VOD – bulk list dann Details parallel, chunked put
            val vod = client.getVodStreams(categoryId = null, offset = 0, limit = Int.MAX_VALUE)
            vodBox.removeAll()
            val sem = Semaphore(6)
            val vodResults = coroutineScope {
                vod.mapNotNull { r ->
                    val vid = r.vod_id ?: return@mapNotNull null
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            val d = client.getVodDetailFull(vid)
                            val images = d?.images ?: emptyList()
                            val catName = vodCatMap[r.category_id.orEmpty()]
                            val provider = normalizeProvider(catName, d?.name ?: r.name)
                            val gKey = deriveGenreKey(d?.name ?: r.name, catName, d?.genre)
                            val y = d?.year
                            val yKey = deriveYearKeyInt(y, d?.name ?: r.name)
                            ObxVod(
                                vodId = vid,
                                nameLower = (d?.name ?: r.name.orEmpty()).lowercase(),
                                sortTitleLower = sortKey(d?.name ?: r.name),
                                name = d?.name ?: r.name.orEmpty(),
                                poster = images.firstOrNull(),
                                imagesJson = runCatching { Json.encodeToString(ListSerializer(String.serializer()), images) }.getOrNull(),
                                year = y,
                                yearKey = yKey,
                                rating = d?.rating,
                                plot = d?.plot,
                                genre = d?.genre,
                                director = d?.director,
                                cast = d?.cast,
                                country = d?.country,
                                releaseDate = d?.releaseDate,
                                imdbId = d?.imdbId,
                                tmdbId = d?.tmdbId,
                                trailer = d?.trailer,
                                containerExt = null,
                                categoryId = r.category_id,
                                providerKey = provider,
                                genreKey = gKey
                            )
                        }
                    }
                }.awaitAll()
            }
            if (vodResults.isNotEmpty()) vodBox.putChunked(vodResults, 2000)

            // Series – bulk list dann Details + Episoden, chunked puts
            val series = client.getSeries(categoryId = null, offset = 0, limit = Int.MAX_VALUE)
            seriesBox.removeAll(); epBox.removeAll()
            val seriesDetails = coroutineScope {
                series.mapNotNull { r ->
                    val sid = r.series_id ?: return@mapNotNull null
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            val d = client.getSeriesDetailFull(sid)
                            val images = d?.images ?: emptyList()
                            val catName = serCatMap[r.category_id.orEmpty()]
                            val provider = normalizeProvider(catName, d?.name ?: r.name)
                            val gKey = deriveGenreKey(d?.name ?: r.name, catName, d?.genre)
                            val y = d?.year
                            val yKey = deriveYearKeyInt(y, d?.name ?: r.name)
                            val sEntity = ObxSeries(
                                seriesId = sid,
                                nameLower = (d?.name ?: r.name.orEmpty()).lowercase(),
                                sortTitleLower = sortKey(d?.name ?: r.name),
                                name = d?.name ?: r.name.orEmpty(),
                                imagesJson = runCatching { Json.encodeToString(ListSerializer(String.serializer()), images) }.getOrNull(),
                                year = y,
                                yearKey = yKey,
                                rating = d?.rating,
                                plot = d?.plot,
                                genre = d?.genre,
                                director = d?.director,
                                cast = d?.cast,
                                imdbId = d?.imdbId,
                                tmdbId = d?.tmdbId,
                                trailer = d?.trailer,
                                categoryId = r.category_id,
                                providerKey = provider,
                                genreKey = gKey
                            )
                            val episodes = mutableListOf<ObxEpisode>()
                            d?.seasons?.forEach { s ->
                                s.episodes.forEach { e ->
                                    episodes += ObxEpisode(
                                        seriesId = sid,
                                        season = s.seasonNumber,
                                        episodeNum = e.episodeNum,
                                        title = e.title,
                                        durationSecs = e.durationSecs,
                                        rating = e.rating,
                                        plot = e.plot,
                                        airDate = e.airDate,
                                        playExt = e.playExt
                                    )
                                }
                            }
                            Pair(sEntity, episodes)
                        }
                    }
                }.awaitAll()
            }
            seriesDetails.forEach { (s, eps) ->
                seriesBox.put(s)
                if (eps.isNotEmpty()) epBox.putChunked(eps, 2000)
            }

            live.size + vod.size + series.size
        }
    }

    // --- EPG upsert helpers (ObjectBox) ---
    suspend fun upsertEpgNowNext(streamId: Int?, channelId: String?, list: List<XtShortEPGProgramme>) = withContext(Dispatchers.IO) {
        val box = ObxStore.get(context).boxFor<ObxEpgNowNext>()
        val now = list.getOrNull(0)
        val next = list.getOrNull(1)
        val row = ObxEpgNowNext(
            streamId = streamId,
            channelId = channelId,
            nowTitle = now?.title,
            nowStartMs = now?.start?.toLongOrNull()?.times(1000),
            nowEndMs = now?.end?.toLongOrNull()?.times(1000),
            nextTitle = next?.title,
            nextStartMs = next?.start?.toLongOrNull()?.times(1000),
            nextEndMs = next?.end?.toLongOrNull()?.times(1000),
            updatedAt = System.currentTimeMillis()
        )
        val existing = when {
            !channelId.isNullOrBlank() -> box.query(ObxEpgNowNext_.channelId.equal(channelId)).build().findFirst()
            streamId != null -> box.query(ObxEpgNowNext_.streamId.equal(streamId.toLong())).build().findFirst()
            else -> null
        }
        if (existing != null) { row.id = existing.id }
        box.put(row)
    }

    // --- EPG prefetch for visible Live IDs (ultra performant, batched) ---
    suspend fun prefetchEpgForVisible(
        streamIds: List<Int>,
        perStreamLimit: Int = 2,
        parallelism: Int = 4
    ) = withContext(Dispatchers.IO) {
        if (streamIds.isEmpty()) return@withContext
        val client = newClient()
        val sem = Semaphore(parallelism)
        val box = ObxStore.get(context).boxFor<ObxEpgNowNext>()
        val rows = mutableListOf<ObxEpgNowNext>()
        coroutineScope {
            streamIds.distinct().forEach { sid ->
                async(Dispatchers.IO) {
                    sem.withPermit {
                        val json = runCatching { client.fetchShortEpg(sid, perStreamLimit) }.getOrNull()
                        val list = parseShortEpg(json)
                        if (list.isNotEmpty()) {
                            val now = list.getOrNull(0)
                            val next = list.getOrNull(1)
                            val obx = ObxEpgNowNext(
                                streamId = sid,
                                channelId = null,
                                nowTitle = now?.title,
                                nowStartMs = now?.start?.toLongOrNull()?.times(1000),
                                nowEndMs = now?.end?.toLongOrNull()?.times(1000),
                                nextTitle = next?.title,
                                nextStartMs = next?.start?.toLongOrNull()?.times(1000),
                                nextEndMs = next?.end?.toLongOrNull()?.times(1000),
                                updatedAt = System.currentTimeMillis()
                            )
                            synchronized(rows) { rows += obx }
                        }
                    }
                }
            }
        }
        if (rows.isNotEmpty()) {
            val existingBySid = box.query(ObxEpgNowNext_.streamId.greater(0)).build().find().associateBy { it.streamId }
            rows.forEach { r -> existingBySid[r.streamId]?.let { r.id = it.id } }
            box.put(rows) // klein (<= 50), kein Chunk nötig
        }
    }

    private fun parseShortEpg(json: String?): List<XtShortEPGProgramme> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val root = kotlinx.serialization.json.Json.parseToJsonElement(json)
            val arr = root.jsonArray
            arr.mapNotNull { el ->
                val obj = el.jsonObject
                XtShortEPGProgramme(
                    title = obj["title"]?.jsonPrimitive?.contentOrNull,
                    start = obj["start"]?.jsonPrimitive?.contentOrNull,
                    end = obj["end"]?.jsonPrimitive?.contentOrNull,
                )
            }
        } catch (_: Throwable) { emptyList() }
    }

    // --- Paged queries (for later UI wiring) ---
    suspend fun categories(kind: String): List<ObxCategory> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxCategory>()
            .query(ObxCategory_.kind.equal(kind))
            .order(ObxCategory_.categoryName)
            .build().find()
    }

    suspend fun livePaged(offset: Long, limit: Long): List<ObxLive> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>()
            .query()
            .order(ObxLive_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun liveByCategoryPaged(categoryId: String, offset: Long, limit: Long): List<ObxLive> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>()
            .query(ObxLive_.categoryId.equal(categoryId))
            .order(ObxLive_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun liveByProviderKeyPaged(key: String, offset: Long, limit: Long): List<ObxLive> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>()
            .query(ObxLive_.providerKey.equal(key))
            .order(ObxLive_.nameLower)
            .build().find(offset, limit)
    }
    suspend fun liveByGenreKeyPaged(key: String, offset: Long, limit: Long): List<ObxLive> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>()
            .query(ObxLive_.genreKey.equal(key))
            .order(ObxLive_.nameLower)
            .build().find(offset, limit)
    }

    suspend fun vodPaged(offset: Long, limit: Long): List<ObxVod> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>()
            .query()
            .order(ObxVod_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun vodByCategoryPaged(categoryId: String, offset: Long, limit: Long): List<ObxVod> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>()
            .query(ObxVod_.categoryId.equal(categoryId))
            .order(ObxVod_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun vodByYearKeyPaged(year: Int, offset: Long, limit: Long): List<ObxVod> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>()
            .query(ObxVod_.yearKey.equal(year))
            .order(ObxVod_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun vodByProviderKeyPaged(key: String, offset: Long, limit: Long): List<ObxVod> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>()
            .query(ObxVod_.providerKey.equal(key))
            .order(ObxVod_.nameLower)
            .build().find(offset, limit)
    }
    suspend fun vodByGenreKeyPaged(key: String, offset: Long, limit: Long): List<ObxVod> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>()
            .query(ObxVod_.genreKey.equal(key))
            .order(ObxVod_.nameLower)
            .build().find(offset, limit)
    }

    suspend fun vodYearKeys(): List<Int> = withContext(Dispatchers.IO) {
        val box = ObxStore.get(context).boxFor<ObxVod>()
        val rows = box.query(ObxVod_.yearKey.greater(0)).orderDesc(ObxVod_.yearKey).build().find()
        rows.mapNotNull { it.yearKey }.fold(mutableListOf<Int>()) { acc, v -> if (acc.lastOrNull() != v) acc.add(v); acc }
    }

    suspend fun seriesPaged(offset: Long, limit: Long): List<ObxSeries> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>()
            .query()
            .order(ObxSeries_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun seriesByCategoryPaged(categoryId: String, offset: Long, limit: Long): List<ObxSeries> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>()
            .query(ObxSeries_.categoryId.equal(categoryId))
            .order(ObxSeries_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun seriesByYearKeyPaged(year: Int, offset: Long, limit: Long): List<ObxSeries> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>()
            .query(ObxSeries_.yearKey.equal(year))
            .order(ObxSeries_.sortTitleLower)
            .build().find(offset, limit)
    }
    suspend fun seriesByProviderKeyPaged(key: String, offset: Long, limit: Long): List<ObxSeries> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>()
            .query(ObxSeries_.providerKey.equal(key))
            .order(ObxSeries_.nameLower)
            .build().find(offset, limit)
    }
    suspend fun seriesByGenreKeyPaged(key: String, offset: Long, limit: Long): List<ObxSeries> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>()
            .query(ObxSeries_.genreKey.equal(key))
            .order(ObxSeries_.nameLower)
            .build().find(offset, limit)
    }

    suspend fun seriesYearKeys(): List<Int> = withContext(Dispatchers.IO) {
        val box = ObxStore.get(context).boxFor<ObxSeries>()
        val rows = box.query(ObxSeries_.yearKey.greater(0)).orderDesc(ObxSeries_.yearKey).build().find()
        rows.mapNotNull { it.yearKey }.fold(mutableListOf<Int>()) { acc, v -> if (acc.lastOrNull() != v) acc.add(v); acc }
    }

    // Counts (for category sheet badges)
    suspend fun countLiveByCategory(categoryId: String): Long = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>().query(ObxLive_.categoryId.equal(categoryId)).build().count()
    }
    suspend fun countVodByCategory(categoryId: String): Long = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>().query(ObxVod_.categoryId.equal(categoryId)).build().count()
    }
    suspend fun countSeriesByCategory(categoryId: String): Long = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>().query(ObxSeries_.categoryId.equal(categoryId)).build().count()
    }

    suspend fun episodesForSeries(seriesId: Int): List<ObxEpisode> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxEpisode>()
            .query(ObxEpisode_.seriesId.equal(seriesId.toLong()))
            .order(ObxEpisode_.season).order(ObxEpisode_.episodeNum)
            .build().find()
    }

    // --- Search (ObjectBox-backed, case-insensitive contains) ---
    private suspend fun categoryIdsMatching(kind: String, qLower: String): Set<String> = withContext(Dispatchers.IO) {
        categories(kind).mapNotNull { it.categoryId.takeIf { _ -> (it.categoryName ?: "").lowercase().contains(qLower) } }.toSet()
    }
    suspend fun searchLiveByName(q: String, offset: Long, limit: Long): List<ObxLive> = withContext(Dispatchers.IO) {
        val ql = q.lowercase(); val box = ObxStore.get(context).boxFor<ObxLive>()
        val nameQ = box.query(ObxLive_.nameLower.contains(ql)).order(ObxLive_.nameLower).build()
        val nameCount = nameQ.count()
        val fromName = when {
            offset >= nameCount -> emptyList()
            else -> nameQ.find(offset, limit)
        }
        if (fromName.size >= limit) return@withContext fromName
        val need = (limit - fromName.size).toInt()
        val catIds = categoryIdsMatching("live", ql)
        if (catIds.isEmpty()) return@withContext fromName
        val catQ = box.query(ObxLive_.categoryId.oneOf(catIds.toTypedArray())).order(ObxLive_.nameLower).build()
        // fetch a bounded window to fill remainder
        val extra = catQ.find(0, (need + 200).toLong()).filterNot { x -> fromName.any { it.streamId == x.streamId } }
        (fromName + extra.take(need)).distinctBy { it.streamId }
    }
    suspend fun searchVodByName(q: String, offset: Long, limit: Long): List<ObxVod> = withContext(Dispatchers.IO) {
        val ql = q.lowercase(); val box = ObxStore.get(context).boxFor<ObxVod>()
        val nameQ = box.query(ObxVod_.nameLower.contains(ql)).order(ObxVod_.nameLower).build()
        val nameCount = nameQ.count()
        val fromName = when {
            offset >= nameCount -> emptyList()
            else -> nameQ.find(offset, limit)
        }
        if (fromName.size >= limit) return@withContext fromName
        val need = (limit - fromName.size).toInt()
        val catIds = categoryIdsMatching("vod", ql)
        if (catIds.isEmpty()) return@withContext fromName
        val catQ = box.query(ObxVod_.categoryId.oneOf(catIds.toTypedArray())).order(ObxVod_.nameLower).build()
        val extra = catQ.find(0, (need + 200).toLong()).filterNot { x -> fromName.any { it.vodId == x.vodId } }
        (fromName + extra.take(need)).distinctBy { it.vodId }
    }
    suspend fun searchSeriesByName(q: String, offset: Long, limit: Long): List<ObxSeries> = withContext(Dispatchers.IO) {
        val ql = q.lowercase(); val box = ObxStore.get(context).boxFor<ObxSeries>()
        val nameQ = box.query(ObxSeries_.nameLower.contains(ql)).order(ObxSeries_.nameLower).build()
        val nameCount = nameQ.count()
        val fromName = when {
            offset >= nameCount -> emptyList()
            else -> nameQ.find(offset, limit)
        }
        if (fromName.size >= limit) return@withContext fromName
        val need = (limit - fromName.size).toInt()
        val catIds = categoryIdsMatching("series", ql)
        if (catIds.isEmpty()) return@withContext fromName
        val catQ = box.query(ObxSeries_.categoryId.oneOf(catIds.toTypedArray())).order(ObxSeries_.nameLower).build()
        val extra = catQ.find(0, (need + 200).toLong()).filterNot { x -> fromName.any { it.seriesId == x.seriesId } }
        (fromName + extra.take(need)).distinctBy { it.seriesId }
    }

    // --- Distinct key lists (for grouped headers without in-memory scans) ---
    suspend fun liveProviderKeys(): List<String> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>().query().build().property(ObxLive_.providerKey).distinct().findStrings().filterNotNull().filter { it.isNotBlank() }.sorted()
    }
    suspend fun liveGenreKeys(): List<String> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxLive>().query().build().property(ObxLive_.genreKey).distinct().findStrings().filterNotNull().filter { it.isNotBlank() }.sorted()
    }
    suspend fun vodProviderKeys(): List<String> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>().query().build().property(ObxVod_.providerKey).distinct().findStrings().filterNotNull().filter { it.isNotBlank() }.sorted()
    }
    suspend fun vodGenreKeys(): List<String> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>().query().build().property(ObxVod_.genreKey).distinct().findStrings().filterNotNull().filter { it.isNotBlank() }.sorted()
    }
    suspend fun vodYears(): List<Int> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxVod>().query().build().property(ObxVod_.yearKey).distinct().findInts().toList().sortedDescending()
    }
    suspend fun seriesProviderKeys(): List<String> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>().query().build().property(ObxSeries_.providerKey).distinct().findStrings().filterNotNull().filter { it.isNotBlank() }.sorted()
    }
    suspend fun seriesGenreKeys(): List<String> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>().query().build().property(ObxSeries_.genreKey).distinct().findStrings().filterNotNull().filter { it.isNotBlank() }.sorted()
    }
    suspend fun seriesYears(): List<Int> = withContext(Dispatchers.IO) {
        ObxStore.get(context).boxFor<ObxSeries>().query().build().property(ObxSeries_.yearKey).distinct().findInts().toList().sortedDescending()
    }

    // ---- helpers ----
    private fun upsertCategories(catBox: Box<ObxCategory>, kind: String, desired: Map<String, String>, deleteOrphans: Boolean) {
        val existing = catBox.query(ObxCategory_.kind.equal(kind)).build().find()
        val existingById = existing.associateBy { it.categoryId.orEmpty() }
        val toUpsert = mutableListOf<ObxCategory>()
        desired.forEach { (id, name) ->
            val ex = existingById[id]
            if (ex == null) {
                toUpsert += ObxCategory(kind = kind, categoryId = id, categoryName = name)
            } else if ((ex.categoryName ?: "") != name) {
                toUpsert += ex.copy(categoryName = name)
            }
        }
        if (toUpsert.isNotEmpty()) catBox.putChunked(toUpsert, 2000)
        if (deleteOrphans) {
            val toRemove = existing.filter { it.categoryId.orEmpty() !in desired.keys }
            if (toRemove.isNotEmpty()) catBox.remove(toRemove)
        }
    }
}

private fun <T> Box<T>.putChunked(items: List<T>, chunkSize: Int = 2000) {
    var i = 0
    val n = items.size
    while (i < n) {
        val to = min(i + chunkSize, n)
        this.put(items.subList(i, to))
        i = to
    }
}

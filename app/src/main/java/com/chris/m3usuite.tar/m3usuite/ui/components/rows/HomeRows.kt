@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class
)
@file:androidx.media3.common.util.UnstableApi

package com.chris.m3usuite.ui.components.rows

import android.net.Uri
import java.util.Locale
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import com.chris.m3usuite.data.repo.EpgRepository
import com.chris.m3usuite.domain.selectors.extractYearFrom
import com.chris.m3usuite.model.MediaItem
import com.chris.m3usuite.prefs.SettingsStore
import com.chris.m3usuite.ui.common.AppIcon
import com.chris.m3usuite.ui.common.AppIconButton
import com.chris.m3usuite.ui.fx.ShimmerBox
import com.chris.m3usuite.ui.fx.ShimmerCircle
import com.chris.m3usuite.ui.skin.tvClickable
import com.chris.m3usuite.ui.util.AppAsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

// -----------------------------------------------------------------------------
// Small, fast helpers
// -----------------------------------------------------------------------------

@Composable
private fun rowItemHeight(): Int {
    val cfg = LocalConfiguration.current
    val isLandscape = cfg.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val sw = cfg.smallestScreenWidthDp
    val isTablet = sw >= 600
    val base = when {
        isTablet && isLandscape -> 230
        isTablet -> 210
        isLandscape -> 200
        else -> 180
    }
    return (base * 1.2f).toInt()
}

@Composable
private fun PlayOverlay(visible: Boolean, sizeDp: Int = 56) {
    val a by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(150),
        label = "playFade"
    )
    if (a > 0f) {
        Box(Modifier.fillMaxSize()) {
            AppIconButton(
                icon = AppIcon.PlayCircle,
                contentDescription = "Abspielen",
                onClick = {},
                modifier = Modifier.align(Alignment.Center).alpha(a),
                size = sizeDp.dp
            )
        }
    }
}

@Composable
private fun ShimmerTile(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .height(rowItemHeight().dp)
            .padding(end = 6.dp)
    ) { ShimmerBox(modifier = Modifier.aspectRatio(16f / 9f), cornerRadius = 14.dp) }
}

// -----------------------------------------------------------------------------
// Tiny card used in ResumeRow etc.
// -----------------------------------------------------------------------------

@Composable
fun MediaCard(
    item: MediaItem,
    onClick: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    showTitle: Boolean = true
) {
    val h = rowItemHeight()
    Column(
        horizontalAlignment = Alignment.Start,
        modifier = modifier
            .height(h.dp)
            .padding(end = 12.dp)
            .tvClickable { onClick(item) }
    ) {
        val imageUrl = remember(item.poster ?: item.logo ?: item.backdrop) {
            item.poster ?: item.logo ?: item.backdrop
        }
        AppAsyncImage(
            url = imageUrl,
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.aspectRatio(16f / 9f)
        )
        if (showTitle) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

// -----------------------------------------------------------------------------
// PosterTileCardBase – gemeinsame, performante Basis für VOD & Serien
// -----------------------------------------------------------------------------

private data class ContextAndId(val ctx: android.content.Context, val id: Long)

@Composable
private fun PosterTileCardBase(
    item: MediaItem,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: ((MediaItem) -> Unit)? = null,
    showAssign: Boolean = true,
    isNew: Boolean = false,
    loadResumeSeconds: suspend (ContextAndId) -> Int? = { null },
) {
    val ctx = LocalContext.current
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    val borderBrush = remember {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent))
    }

    Card(
        modifier = Modifier
            .height(rowItemHeight().dp)
            .padding(end = 6.dp)
            .tvClickable(scaleFocused = 1.12f, scalePressed = 1.16f, elevationFocusedDp = 18f) {
                onOpenDetails(item)
            }
            .onFocusChanged { focused = it.isFocused || it.hasFocus }
            .border(1.dp, borderBrush, shape)
            .drawWithContent {
                drawContent()
                val grad = Brush.verticalGradient(
                    0f to Color.White.copy(alpha = if (focused) 0.18f else 0.10f),
                    1f to Color.Transparent
                )
                drawRect(brush = grad)
            },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = shape
    ) {
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                var loaded by remember { mutableStateOf(false) }
                if (!loaded) {
                    ShimmerBox(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                        cornerRadius = 0.dp
                    )
                }
                AppAsyncImage(
                    url = item.poster ?: item.logo ?: item.backdrop,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    onLoading = { loaded = false },
                    onSuccess = { loaded = true },
                    onError = { loaded = true }
                )

                var resumeSecs by remember(item.id) { mutableStateOf<Int?>(null) }
                LaunchedEffect(item.id) {
                    resumeSecs = try {
                        withContext(Dispatchers.IO) { loadResumeSeconds(ContextAndId(ctx, item.id)) }
                    } catch (_: Throwable) { null }
                }
                val total = item.durationSecs ?: 0
                if ((resumeSecs ?: 0) > 0 && total > 0) {
                    val errorColor = MaterialTheme.colorScheme.error
                    Canvas(Modifier.matchParentSize()) {
                        val w = size.width
                        val h = size.height
                        val y = h - 10f
                        val margin = w * 0.06f
                        val start = Offset(margin, y)
                        val end = Offset(w - margin, y)
                        val frac = (resumeSecs!!.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                        val fillEnd = Offset(start.x + (end.x - start.x) * frac, y)
                        drawLine(
                            color = Color.White.copy(alpha = 0.35f),
                            start = start, end = end, strokeWidth = 3f,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                        drawLine(
                            color = errorColor,
                            start = start, end = fillEnd, strokeWidth = 3.5f,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                    }
                    if (focused) {
                        val secs = (resumeSecs ?: 0).coerceAtLeast(0)
                        val pct = if (total > 0) ((secs * 100) / total) else 0
                        Box(Modifier.matchParentSize()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.Black.copy(alpha = 0.65f),
                                contentColor = Color.White,
                                modifier = Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 8.dp)
                            ) {
                                Text(
                                    text = String.format(Locale.getDefault(), "Weiter %d:%02d (%d%%)", secs / 60, secs % 60, pct),
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                PlayOverlay(visible = focused, sizeDp = 56)
            }

            if (focused) {
                val y = item.year ?: extractYearFrom(item.name)
                val title = item.name.substringAfter(" - ", item.name)
                Text(
                    text = if (y != null) "$title ($y)" else title,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
                val plot = item.plot
                if (!plot.isNullOrBlank()) {
                    Text(
                        text = plot,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
            }

            if (isNew) {
                Text(
                    text = "NEU",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Red,
                    modifier = Modifier.padding(start = 10.dp, bottom = 8.dp)
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(end = 8.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                AppIconButton(
                    icon = AppIcon.PlayCircle,
                    contentDescription = "Abspielen",
                    onClick = { onPlayDirect(item) },
                    size = 24.dp
                )
                if (showAssign && onAssignToKid != null) {
                    AppIconButton(
                        icon = AppIcon.BookmarkAdd,
                        contentDescription = "Für Kinder freigeben",
                        onClick = { onAssignToKid(item) },
                        size = 24.dp
                    )
                }
            }
        }
    }
}

@Composable
fun VodTileCard(
    item: MediaItem,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: (MediaItem) -> Unit,
    isNew: Boolean = false,
    showAssign: Boolean = true
) {
    PosterTileCardBase(
        item = item,
        onOpenDetails = onOpenDetails,
        onPlayDirect = onPlayDirect,
        onAssignToKid = onAssignToKid,
        showAssign = showAssign,
        isNew = isNew,
        loadResumeSeconds = { (ctx, id) ->
            com.chris.m3usuite.data.repo.ResumeRepository(ctx).getVodResume(id)
        }
    )
}

@Composable
fun SeriesTileCard(
    item: MediaItem,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: (MediaItem) -> Unit,
    isNew: Boolean = false,
    showAssign: Boolean = true
) {
    PosterTileCardBase(
        item = item,
        onOpenDetails = onOpenDetails,
        onPlayDirect = onPlayDirect,
        onAssignToKid = onAssignToKid,
        showAssign = showAssign,
        isNew = isNew,
        loadResumeSeconds = { (ctx, id) ->
            com.chris.m3usuite.data.repo.ResumeRepository(ctx).getVodResume(id)
        }
    )
}

// -----------------------------------------------------------------------------
// Live-Kachel (EPG, optionaler Video-Preview), inkl. Reorder-Indikatoren
// -----------------------------------------------------------------------------

@Composable
fun LiveTileCard(
    item: MediaItem,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    selected: Boolean = false,
    onLongPress: (() -> Unit)? = null,
    onMoveLeft: (() -> Unit)? = null,
    onMoveRight: (() -> Unit)? = null,
    insertionLeft: Boolean = false,
    insertionRight: Boolean = false
) {
    val ctx = LocalContext.current
    val store = remember { SettingsStore(ctx) }
    val ua by store.userAgent.collectAsStateWithLifecycle(initialValue = "")
    val ref by store.referer.collectAsStateWithLifecycle(initialValue = "")
    val extraJson by store.extraHeadersJson.collectAsStateWithLifecycle(initialValue = "")
    // Reused EPG repository (neu: einmal merken, nicht jedes Mal neu instanziieren)
    val epgRepo = remember(store) { EpgRepository(ctx, store) }

    var epgNow by remember { mutableStateOf("") }
    var epgNext by remember { mutableStateOf("") }
    var nowStartMs by remember { mutableStateOf<Long?>(null) }
    var nowEndMs by remember { mutableStateOf<Long?>(null) }
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    val borderBrush = remember {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent))
    }

    val epgChannelId = remember(item.epgChannelId) { item.epgChannelId?.trim().orEmpty() }
    if (epgChannelId.isNotEmpty()) {
        val box = remember {
            com.chris.m3usuite.data.obx.ObxStore.get(ctx)
                .boxFor(com.chris.m3usuite.data.obx.ObxEpgNowNext::class.java)
        }
        DisposableEffect(epgChannelId) {
            val q = box.query(
                com.chris.m3usuite.data.obx.ObxEpgNowNext_.channelId.equal(epgChannelId)
            ).build()
            fun apply(row: com.chris.m3usuite.data.obx.ObxEpgNowNext?) {
                epgNow = row?.nowTitle.orEmpty()
                epgNext = row?.nextTitle.orEmpty()
                nowStartMs = row?.nowStartMs
                nowEndMs = row?.nowEndMs
            }
            apply(q.findFirst())
            val sub = q.subscribe()
                .on(io.objectbox.android.AndroidScheduler.mainThread())
                .observer { res -> apply(res.firstOrNull()) }
            onDispose { sub.cancel() }
        }
    }

    LaunchedEffect(item.streamId, focused) {
        val sid = item.streamId ?: return@LaunchedEffect
        if (!focused) return@LaunchedEffect
        try {
            val list = epgRepo.nowNext(sid, 2)
            val first = list.getOrNull(0)
            val second = list.getOrNull(1)
            epgNow = first?.title.orEmpty()
            epgNext = second?.title.orEmpty()
            val start = first?.start?.toLongOrNull()?.let { it * 1000 }
            val end = first?.end?.toLongOrNull()?.let { it * 1000 }
            nowStartMs = start; nowEndMs = end
        } catch (_: Throwable) {
            epgNow = ""; epgNext = ""; nowStartMs = null; nowEndMs = null
        }
    }

    Card(
        modifier = Modifier
            .height(rowItemHeight().dp)
            .padding(end = 6.dp)
            .combinedClickable(
                onClick = { onOpenDetails(item) },
                onLongClick = { onLongPress?.invoke() }
            )
            .onFocusChanged { focused = it.isFocused || it.hasFocus }
            .border(1.dp, borderBrush, shape)
            .drawWithContent {
                drawContent()
                val grad = Brush.verticalGradient(0f to Color.White.copy(alpha = 0.12f), 1f to Color.Transparent)
                drawRect(brush = grad)
            },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = shape
    ) {
        Box(Modifier.fillMaxWidth()) {

            if (insertionLeft) {
                Box(
                    Modifier
                        .align(Alignment.CenterStart)
                        .width(3.dp)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
            if (insertionRight) {
                Box(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .width(3.dp)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.primary)
                )
            }

            val preview = remember { false }
            if (preview && !item.url.isNullOrBlank()) {
                val url = item.url!!
                AndroidView(
                    factory = { c ->
                        val view = PlayerView(c)
                        val httpFactory = DefaultHttpDataSource.Factory().apply {
                            val effUa = (if (ua.isNotBlank()) ua else "IBOPlayer/1.4 (Android)")
                            if (effUa.isNotBlank()) setUserAgent(effUa)
                        }
                            .setAllowCrossProtocolRedirects(true)
                            .apply {
                                val base = buildMap<String, String> {
                                    val effUa = (if (ua.isNotBlank()) ua else "IBOPlayer/1.4 (Android)")
                                    if (effUa.isNotBlank()) put("User-Agent", effUa)
                                    if (ref.isNotBlank()) put("Referer", ref)
                                    put("Accept", "*/*")
                                }
                                val extras = com.chris.m3usuite.core.http.RequestHeadersProvider
                                    .parseExtraHeaders(extraJson)
                                val merged = com.chris.m3usuite.core.http.RequestHeadersProvider
                                    .merge(base, extras)
                                if (merged.isNotEmpty()) setDefaultRequestProperties(merged)
                            }
                        val dsFactory = DefaultDataSource.Factory(c, httpFactory)
                        val mediaFactory = DefaultMediaSourceFactory(dsFactory)
                        val player = ExoPlayer.Builder(c)
                            .setMediaSourceFactory(mediaFactory)
                            .build().apply {
                                volume = 0f
                                repeatMode = ExoPlayer.REPEAT_MODE_ALL
                                playWhenReady = true
                                setMediaItem(ExoMediaItem.fromUri(Uri.parse(url)))
                                prepare()
                            }
                        view.player = player
                        view.useController = false
                        view.tag = player
                        view
                    },
                    modifier = Modifier.fillMaxWidth().graphicsLayer(alpha = 0.7f),
                    update = { v -> (v.tag as? ExoPlayer)?.let { if (!it.playWhenReady) it.playWhenReady = true } },
                    onRelease = { v -> (v.tag as? ExoPlayer)?.release() }
                )
            }

            val sz = 77.dp
            val logoTop = 8.dp
            val epgTop = logoTop + sz + 8.dp
            val logoUrl = item.logo ?: item.poster
            run {
                var loaded by remember { mutableStateOf(false) }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = logoTop)
                        .size(sz)
                ) {
                    if (!loaded) ShimmerCircle(Modifier.fillMaxSize())
                    if (logoUrl != null) {
                        AppAsyncImage(
                            url = logoUrl,
                            contentDescription = item.name,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .border(2.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), CircleShape),
                            onLoading = { loaded = false },
                            onSuccess = { loaded = true },
                            onError = { loaded = true }
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .border(2.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), CircleShape)
                        )
                    }
                }
            }

            if (selected) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = 0.18f }
                        .background(Color.Yellow.copy(alpha = 0.2f))
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1DB954))
            )

            val hasEpg = epgNow.isNotBlank() || epgNext.isNotBlank()
            if (hasEpg) {
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = epgTop)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.70f))
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (epgNow.isNotBlank()) {
                        Text(
                            text = epgNow,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (epgNext.isNotBlank()) {
                        Text(
                            text = epgNext,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(8.dp),
                    tonalElevation = 0.dp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(end = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    AppIconButton(
                        icon = AppIcon.PlayCircle,
                        contentDescription = "Abspielen",
                        onClick = { onPlayDirect(item) },
                        size = 24.dp
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// Rows – identische Optik, Snap-Scroll, schrittweise Item-Freigabe
// -----------------------------------------------------------------------------

@Composable
fun ResumeRow(
    items: List<MediaItem>,
    onClick: (MediaItem) -> Unit,
) {
    if (items.isEmpty()) return
    val slice = remember(items) { items.distinctBy { it.id }.take(5) }
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, slice) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val visibleIds = idxs.mapNotNull { i -> slice.getOrNull(i)?.streamId }.filterNotNull()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        items(slice, key = { it.id }) { m ->
            MediaCard(item = m, onClick = onClick)
        }
    }
}

@Composable
fun LiveRow(
    items: List<MediaItem>,
    leading: (@Composable (() -> Unit))? = null,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
) {
    if (items.isEmpty()) return
    val unique = remember(items) { items.distinctBy { it.id } }
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    var count by remember(unique) { mutableIntStateOf(if (unique.size < 30) unique.size else 30) }
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collectLatest { idx ->
                if (idx > count - 20 && count < unique.size) {
                    count = (count + 50).coerceAtMost(unique.size)
                }
            }
    }

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, unique) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val visibleIds = idxs.mapNotNull { i -> unique.getOrNull(i)?.streamId }.filterNotNull()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        if (leading != null) item("leading") { leading() }
        items(unique.take(count), key = { it.id }) { m ->
            LiveTileCard(item = m, onOpenDetails = onOpenDetails, onPlayDirect = onPlayDirect)
        }
    }
}

@Composable
fun VodRow(
    items: List<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: (MediaItem) -> Unit,
    showNew: Boolean = false,
    showAssign: Boolean = true
) {
    if (items.isEmpty()) return
    val unique = remember(items) { items.distinctBy { it.id } }
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, unique) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val visibleIds = idxs.mapNotNull { i -> unique.getOrNull(i)?.streamId }.filterNotNull()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    var count by remember(unique) { mutableIntStateOf(if (unique.size < 30) unique.size else 30) }
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collectLatest { idx ->
                if (idx > count - 20 && count < unique.size) {
                    count = (count + 50).coerceAtMost(unique.size)
                }
            }
    }
    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        items(unique.take(count), key = { it.id }) { m ->
            VodTileCard(
                item = m,
                onOpenDetails = onOpenDetails,
                onPlayDirect = onPlayDirect,
                onAssignToKid = onAssignToKid,
                isNew = showNew,
                showAssign = showAssign
            )
        }
    }
}

@Composable
fun SeriesRow(
    items: List<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: (MediaItem) -> Unit,
    showNew: Boolean = false,
    showAssign: Boolean = true
) {
    if (items.isEmpty()) return
    val unique = remember(items) { items.distinctBy { it.id } }
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, unique) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val visibleIds = idxs.mapNotNull { i -> unique.getOrNull(i)?.streamId }.filterNotNull()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    var count by remember(unique) { mutableIntStateOf(if (unique.size < 30) unique.size else 30) }
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collectLatest { idx ->
                if (idx > count - 20 && count < unique.size) {
                    count = (count + 50).coerceAtMost(unique.size)
                }
            }
    }
    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        items(unique.take(count), key = { it.id }) { m ->
            SeriesTileCard(
                item = m,
                onOpenDetails = onOpenDetails,
                onPlayDirect = onPlayDirect,
                onAssignToKid = onAssignToKid,
                isNew = showNew,
                showAssign = showAssign
            )
        }
    }
}

// -----------------------------------------------------------------------------
// Paging-Varianten (Skeletons beim Refresh/Append)
// -----------------------------------------------------------------------------

@Composable
fun LiveRowPaged(
    items: LazyPagingItems<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
) {
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items (Paging)
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, items) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val count = items.itemCount
                val visibleIds = idxs.asSequence()
                    .filter { it in 0 until count }
                    .mapNotNull { i -> items.peek(i)?.streamId }
                    .filterNotNull()
                    .toList()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        val isRefreshing = items.loadState.refresh is LoadState.Loading && items.itemCount == 0
        if (isRefreshing) items(10, key = { it }) { ShimmerTile() }

        items(items.itemCount, key = { idx -> items[idx]?.id ?: idx.toLong() }) { index ->
            val mi = items[index] ?: return@items
            LiveTileCard(item = mi, onOpenDetails = onOpenDetails, onPlayDirect = onPlayDirect)
        }

        val isAppending = items.loadState.append is LoadState.Loading
        if (isAppending) items(6, key = { it + 200000 }) { ShimmerTile() }
    }
}

@Composable
fun VodRowPaged(
    items: LazyPagingItems<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: (MediaItem) -> Unit,
    showAssign: Boolean = true
) {
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items (Paging)
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, items) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val count = items.itemCount
                val visibleIds = idxs.asSequence()
                    .filter { it in 0 until count }
                    .mapNotNull { i -> items.peek(i)?.streamId }
                    .filterNotNull()
                    .toList()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        val isRefreshing = items.loadState.refresh is LoadState.Loading && items.itemCount == 0
        if (isRefreshing) items(10, key = { it }) { ShimmerTile() }

        items(items.itemCount, key = { idx -> items[idx]?.id ?: idx.toLong() }) { index ->
            val mi = items[index] ?: return@items
            VodTileCard(
                item = mi,
                onOpenDetails = onOpenDetails,
                onPlayDirect = onPlayDirect,
                onAssignToKid = onAssignToKid,
                isNew = false,
                showAssign = showAssign
            )
        }

        val isAppending = items.loadState.append is LoadState.Loading
        if (isAppending) items(6, key = { it + 100000 }) { ShimmerTile() }
    }
}

@Composable
fun SeriesRowPaged(
    items: LazyPagingItems<MediaItem>,
    onOpenDetails: (MediaItem) -> Unit,
    onPlayDirect: (MediaItem) -> Unit,
    onAssignToKid: (MediaItem) -> Unit,
    showAssign: Boolean = true
) {
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(state)

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items (Paging)
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, items) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val count = items.itemCount
                val visibleIds = idxs.asSequence()
                    .filter { it in 0 until count }
                    .mapNotNull { i -> items.peek(i)?.streamId }
                    .filterNotNull()
                    .toList()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    LazyRow(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        val isRefreshing = items.loadState.refresh is LoadState.Loading && items.itemCount == 0
        if (isRefreshing) items(10, key = { it }) { ShimmerTile() }

        items(items.itemCount, key = { idx -> items[idx]?.id ?: idx.toLong() }) { index ->
            val mi = items[index] ?: return@items
            SeriesTileCard(
                item = mi,
                onOpenDetails = onOpenDetails,
                onPlayDirect = onPlayDirect,
                onAssignToKid = onAssignToKid,
                isNew = false,
                showAssign = showAssign
            )
        }

        val isAppending = items.loadState.append is LoadState.Loading
        if (isAppending) items(6, key = { it + 300000 }) { ShimmerTile() }
    }
}

// -----------------------------------------------------------------------------
// Live-Reorder – UI gleich, Verhalten gestrafft
// -----------------------------------------------------------------------------

@Composable
fun LiveAddTile(onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    val borderBrush = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent))
    Card(
        modifier = Modifier
            .height(rowItemHeight().dp)
            .padding(end = 6.dp)
            .tvClickable(scaleFocused = 1.12f, scalePressed = 1.16f, elevationFocusedDp = 18f) { onClick() }
            .border(1.dp, borderBrush, shape)
            .drawWithContent {
                drawContent()
                val grad = Brush.verticalGradient(0f to Color.White.copy(alpha = 0.12f), 1f to Color.Transparent)
                drawRect(brush = grad)
            },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = shape
    ) {
        Box(Modifier.fillMaxWidth()) {
            AppIconButton(
                icon = AppIcon.BookmarkAdd,
                contentDescription = "Sender hinzufügen",
                onClick = onClick,
                modifier = Modifier.align(Alignment.Center),
                size = 36.dp
            )
        }
    }
}

@Composable
fun ReorderableLiveRow(
    items: List<MediaItem>,
    onOpen: (Long) -> Unit,
    onPlay: (Long) -> Unit,
    onAdd: () -> Unit,
    onReorder: (List<Long>) -> Unit,
    onRemove: (List<Long>) -> Unit
) {
    val state = rememberLazyListState()

    // UI-Hook: Prefetch EPG (Now/Next) für sichtbare Items
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val epgRepo = remember(settings) { EpgRepository(ctx, settings) }
    LaunchedEffect(state, items) {
        snapshotFlow { state.layoutInfo.visibleItemsInfo.map { it.index } }
            .distinctUntilChanged()
            .collectLatest { idxs ->
                val visibleIds = idxs.mapNotNull { i -> items.getOrNull(i)?.streamId }.filterNotNull()
                if (visibleIds.isNotEmpty()) {
                    epgRepo.prefetchNowNext(visibleIds, limit = 2)
                }
            }
    }

    val order = remember(items) { mutableStateListOf<Long>().apply { addAll(items.map { it.id }.distinct()) } }
    var draggingId by remember { mutableStateOf<Long?>(null) }
    var dragOffset by remember { mutableStateOf(0f) }
    var targetKey by remember { mutableStateOf<Long?>(null) }
    var insertAfter by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    val tileLift by animateFloatAsState(if (draggingId != null) 1.05f else 1f, label = "lift")

    LazyRow(
        state = state,
        flingBehavior = rememberSnapFlingBehavior(state),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)
    ) {
        item("leading") { LiveAddTile(onClick = onAdd) }
        items(order, key = { it }) { id ->
            val mi = items.find { it.id == id } ?: return@items
            val isDragging = draggingId == id
            val trans by animateFloatAsState(if (isDragging) dragOffset else 0f, label = "drag")
            val padStart = if (targetKey == id && !insertAfter) 10.dp else 0.dp
            val padEnd = if (targetKey == id && insertAfter) 10.dp else 0.dp
            Box(
                Modifier
                    .padding(start = padStart, end = padEnd)
                    .graphicsLayer {
                        translationX = trans
                        scaleX = if (isDragging) tileLift else 1f
                        scaleY = if (isDragging) tileLift else 1f
                        shadowElevation = if (isDragging) 18f else 0f
                    }
                    .pointerInput(id) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { draggingId = id; dragOffset = 0f },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                dragOffset += dragAmount.x
                                val visible = state.layoutInfo.visibleItemsInfo
                                val current = visible.find { it.key == id }
                                if (current != null) {
                                    val center = current.offset + dragOffset + current.size / 2f
                                    val others = visible.filter { it.key is Long && it.key != id }
                                    val target = others.minByOrNull { kotlin.math.abs(center - (it.offset + it.size / 2f)) }
                                    if (target != null) {
                                        val toKey = target.key as Long
                                        val from = order.indexOf(id)
                                        val to = order.indexOf(toKey)
                                        insertAfter = center > (target.offset + target.size / 2f)
                                        targetKey = toKey
                                        if (from != -1 && to != -1 && from != to) {
                                            order.removeAt(from)
                                            val insertIndex =
                                                if (insertAfter) to + (if (from < to) 0 else 1)
                                                else to + (if (from < to) -1 else 0)
                                            order.add(insertIndex.coerceIn(0, order.size), id)
                                        }
                                    }
                                }
                            },
                            onDragEnd = { draggingId = null; dragOffset = 0f; targetKey = null; onReorder(order.toList()) },
                            onDragCancel = { draggingId = null; dragOffset = 0f; targetKey = null }
                        )
                    }
            ) {
                LiveTileCard(
                    item = mi,
                    onOpenDetails = { if (draggingId == null) onOpen(mi.id) },
                    onPlayDirect = { if (draggingId == null) onPlay(mi.id) },
                    selected = id in selected,
                    onLongPress = { selected = if (id in selected) selected - id else selected + id },
                    onMoveLeft = null,
                    onMoveRight = null,
                    insertionLeft = (targetKey == id && !insertAfter),
                    insertionRight = (targetKey == id && insertAfter)
                )
            }
        }
    }

    if (selected.isNotEmpty()) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)
        ) {
            TextButton(onClick = { selected = emptySet() }) { Text("Abbrechen") }
            TextButton(onClick = { onRemove(selected.toList()); selected = emptySet() }) {
                Text("Entfernen (${selected.size})")
            }
        }
    }
}

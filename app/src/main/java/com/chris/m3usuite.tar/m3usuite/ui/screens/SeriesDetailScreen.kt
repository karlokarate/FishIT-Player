package com.chris.m3usuite.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.util.UnstableApi
import com.chris.m3usuite.model.Episode
import com.chris.m3usuite.player.InternalPlayerScreen
import com.chris.m3usuite.player.PlayerChooser
import com.chris.m3usuite.prefs.SettingsStore
import com.chris.m3usuite.ui.common.AppIconButton
import com.chris.m3usuite.ui.components.sheets.KidSelectSheet
import com.chris.m3usuite.ui.fx.FadeThrough
import com.chris.m3usuite.ui.home.HomeChromeScaffold
import com.chris.m3usuite.ui.skin.focusScaleOnTv
import com.chris.m3usuite.ui.skin.tvClickable
import com.chris.m3usuite.ui.theme.DesignTokens
import com.chris.m3usuite.ui.util.AppAsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import kotlin.math.max

// ----------------------------
// Vorcompilierte Regex/Helper
// ----------------------------
private val COUNTRY_PARENS = Regex("""\s*\(([A-Z]{2,3})(/[A-Z]{2,3})*\)\s*""")
private val YEAR_PARENS = Regex("""\s*\(\d{4}\)\s*""")
private val SEASON_EP_MARK = Regex("""(?i)S\d{1,2}E\d{1,3}""")
private val EXTRA_SEPARATORS = Regex("""[-:–]+""")

private fun cleanSeriesName(raw: String, year: Int?): String {
    var base = raw.substringAfter(" - ", raw)
    if (year != null) base = base.replace(" ($year)", "")
    base = base.replace(COUNTRY_PARENS, " ")
    return base.trim()
}

private fun cleanEpisodeTitle(raw: String?, seriesName: String?): String {
    val lastSeg = raw.orEmpty().split(" - ").lastOrNull()?.trim().orEmpty()
    var t = if (lastSeg.isNotEmpty()) lastSeg else raw.orEmpty()
    if (!seriesName.isNullOrBlank()) t = t.removePrefix(seriesName).trim()
    t = t.replace(YEAR_PARENS, " ")
    t = t.replace(COUNTRY_PARENS, " ")
    t = t.replace(SEASON_EP_MARK, " ")
    t = t.replace(EXTRA_SEPARATORS, " ")
    return t.trim()
}

private fun fmt(totalSecs: Int): String {
    val s = max(0, totalSecs)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.media3.common.util.UnstableApi
@Composable
fun SeriesDetailScreen(
    id: Long,
    // optionaler Callback für internen Player (url, startMs, seriesId, season, episodeNum)
    openInternal: ((url: String, startMs: Long?, seriesId: Int, season: Int, episodeNum: Int) -> Unit)? = null,
    onLogo: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val store = remember { SettingsStore(ctx) }
    val scope = rememberCoroutineScope()
    val profileId by store.currentProfileId.collectAsStateWithLifecycle(initialValue = -1L)

    // Profiltyp (Adult/Kid)
    var isAdult by remember { mutableStateOf(true) }
    LaunchedEffect(profileId) {
        isAdult = withContext(Dispatchers.IO) {
            com.chris.m3usuite.data.obx.ObxStore
                .get(ctx)
                .boxFor(com.chris.m3usuite.data.obx.ObxProfile::class.java)
                .get(profileId)?.type != "kid"
        }
    }

    // Kid‑Gate für diese Serie
    val mediaRepo = remember { com.chris.m3usuite.data.repo.MediaQueryRepository(ctx, store) }
    var contentAllowed by remember { mutableStateOf(true) }
    LaunchedEffect(id, profileId) {
        val prof = withContext(Dispatchers.IO) {
            com.chris.m3usuite.data.obx.ObxStore
                .get(ctx)
                .boxFor(com.chris.m3usuite.data.obx.ObxProfile::class.java)
                .get(profileId)
        }
        val adult = prof?.type == "adult"
        contentAllowed = if (adult) true else mediaRepo.isAllowed("series", id)
    }

    // Kinder-Freigabe
    val kidRepo = remember { com.chris.m3usuite.data.repo.KidContentRepository(ctx) }
    var showGrantSheet by remember { mutableStateOf(false) }
    var showRevokeSheet by remember { mutableStateOf(false) }

    // --- UI/State ---
    var title by remember { mutableStateOf("") }
    var poster by remember { mutableStateOf<String?>(null) }
    var plot by remember { mutableStateOf<String?>(null) }
    var seriesStreamId by remember { mutableStateOf<Int?>(null) }
    var year by remember { mutableStateOf<Int?>(null) }

    var allEpisodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var seasons by remember { mutableStateOf<List<Int>>(emptyList()) }
    var seasonSel by remember { mutableStateOf<Int?>(null) }

    // Abgeleitete Episodenliste der aktuellen Season (lokales Filtern)
    val episodes by remember(seasonSel, allEpisodes) {
        derivedStateOf {
            val s = seasonSel
            if (s == null) emptyList() else allEpisodes.filter { it.season == s }
        }
    }

    // Daten laden (Serie + Episoden EINMAL)
    LaunchedEffect(id) {
        fun decodeObxSeriesId(v: Long): Int? =
            if (v >= 3_000_000_000_000L) (v - 3_000_000_000_000L).toInt() else null

        val obxSid = decodeObxSeriesId(id) ?: return@LaunchedEffect
        seriesStreamId = obxSid

        // Serie (Titel, Poster, Plot, Jahr)
        withContext(Dispatchers.IO) {
            val box = com.chris.m3usuite.data.obx.ObxStore
                .get(ctx)
                .boxFor(com.chris.m3usuite.data.obx.ObxSeries::class.java)
            val row = box.query(
                com.chris.m3usuite.data.obx.ObxSeries_.seriesId.equal(obxSid.toLong())
            ).build().findFirst()

            title = row?.name.orEmpty()
            poster = row?.imagesJson?.let {
                runCatching { JSONArray(it).optString(0, null) }.getOrNull()
            }
            plot = row?.plot
            year = row?.year
        }

        // Episoden holen; bei Leerstand einmal importieren und erneut lesen
        suspend fun fetchAll(): List<Episode> {
            val repo = com.chris.m3usuite.data.repo.XtreamObxRepository(ctx, store)
            var raw = withContext(Dispatchers.IO) { repo.episodesForSeries(obxSid) }
            if (raw.isEmpty()) {
                withContext(Dispatchers.IO) { repo.importSeriesDetailOnce(obxSid) }
                raw = withContext(Dispatchers.IO) { repo.episodesForSeries(obxSid) }
            }
            return raw.map { e ->
                Episode(
                    seriesStreamId = obxSid,
                    episodeId = 0, // Episode-URL wird aus series/season/episode gebaut
                    season = e.season,
                    episodeNum = e.episodeNum,
                    title = e.title ?: "Episode ${e.episodeNum}",
                    plot = e.plot,
                    durationSecs = e.durationSecs,
                    rating = e.rating,
                    airDate = e.airDate,
                    containerExt = e.playExt,
                    poster = null
                )
            }.sortedWith(compareBy({ it.season }, { it.episodeNum }))
        }

        val mapped = fetchAll()
        allEpisodes = mapped
        seasons = mapped.asSequence().map { it.season }.distinct().sorted().toList()
        seasonSel = seasons.firstOrNull()
    }

    // --- Interner Player Zustand (Fullscreen) ---
    var showInternal by remember { mutableStateOf(false) }
    var internalUrl by remember { mutableStateOf<String?>(null) }
    var internalStartMs by remember { mutableStateOf<Long?>(null) }
    var internalEpisodeId by remember { mutableStateOf<Int?>(null) }
    var internalUa by remember { mutableStateOf("") }
    var internalRef by remember { mutableStateOf("") }
    var nextHintEpisodeId by remember { mutableStateOf<Int?>(null) }
    var nextHintText by remember { mutableStateOf<String?>(null) }
    var resumeRefreshKey by remember { mutableStateOf(0) }

    if (showInternal) {
        val hdrs = mutableMapOf<String, String>().apply {
            if (internalUa.isNotBlank()) this["User-Agent"] = internalUa
            if (internalRef.isNotBlank()) this["Referer"] = internalRef
        }
        InternalPlayerScreen(
            url = internalUrl.orEmpty(),
            type = "series",
            episodeId = internalEpisodeId,
            startPositionMs = internalStartMs,
            headers = hdrs,
            onExit = { showInternal = false }
        )
        return
    }

    // Nach Player-Exit: kurzer „Next“-Hinweis (derzeit ohne EpisodeId‑Pfad)
    LaunchedEffect(showInternal) {
        if (!showInternal && internalEpisodeId != null) {
            nextHintEpisodeId = null
            nextHintText = null
            resumeRefreshKey++
        }
    }

    fun playEpisode(e: Episode, fromStart: Boolean = false, resumeSecs: Int? = null) {
        scope.launch {
            if (!contentAllowed) {
                android.widget.Toast
                    .makeText(ctx, "Nicht freigegeben", android.widget.Toast.LENGTH_SHORT)
                    .show()
                return@launch
            }
            val startMs: Long? = if (!fromStart) resumeSecs?.toLong()?.times(1000) else null

            // Telegram bevorzugen, wenn Referenzen existieren
            val tgUrl = if (e.tgChatId != null && e.tgMessageId != null)
                "tg://message?chatId=${e.tgChatId}&messageId=${e.tgMessageId}" else null

            val headers = com.chris.m3usuite.core.http.RequestHeadersProvider.defaultHeaders(store)
            val urlToPlay = tgUrl ?: run {
                val snap = store.snapshot()
                if (snap.xtHost.isNotBlank() && snap.xtUser.isNotBlank() && snap.xtPass.isNotBlank()) {
                    val scheme = if (snap.xtPort == 443) "https" else "http"
                    val http = com.chris.m3usuite.core.http.HttpClientFactory.create(ctx, store)
                    val client = com.chris.m3usuite.core.xtream.XtreamClient(http)
                    val caps = com.chris.m3usuite.core.xtream.ProviderCapabilityStore(ctx)
                    val ports = com.chris.m3usuite.core.xtream.EndpointPortStore(ctx)
                    client.initialize(
                        scheme = scheme,
                        host = snap.xtHost,
                        username = snap.xtUser,
                        password = snap.xtPass,
                        basePath = null,
                        store = caps,
                        portStore = ports,
                        portOverride = snap.xtPort
                    )
                    client.buildSeriesEpisodePlayUrl(seriesStreamId ?: 0, e.season, e.episodeNum, e.containerExt)
                } else null
            } ?: return@launch

            PlayerChooser.start(
                context = ctx,
                store = store,
                url = urlToPlay,
                headers = headers,
                startPositionMs = startMs
            ) { s ->
                if (openInternal != null) {
                    openInternal(urlToPlay, s, seriesStreamId ?: 0, e.season, e.episodeNum)
                } else {
                    internalUrl = urlToPlay
                    internalEpisodeId = null
                    internalStartMs = s
                    internalUa = headers["User-Agent"].orEmpty()
                    internalRef = headers["Referer"].orEmpty()
                    showInternal = true
                }
            }
        }
    }

    val listState = rememberLazyListState()

    HomeChromeScaffold(
        title = "Serie",
        onSettings = null,
        onSearch = null,
        onProfiles = null,
        onRefresh = null,
        listState = listState,
        onLogo = onLogo,
        bottomBar = {}
    ) { pads ->
        Box(Modifier.fillMaxSize().padding(pads)) {
            val accent = if (!isAdult) DesignTokens.KidAccent else DesignTokens.Accent
            val badgeColor = if (!isAdult) accent.copy(alpha = 0.26f) else accent.copy(alpha = 0.20f)
            val badgeColorDarker = if (!isAdult) accent.copy(alpha = 0.32f) else accent.copy(alpha = 0.26f)

            // Hintergrund
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            0f to MaterialTheme.colorScheme.background,
                            1f to MaterialTheme.colorScheme.surface
                        )
                    )
            )
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                accent.copy(alpha = if (!isAdult) 0.20f else 0.12f),
                                Color.Transparent
                            ),
                            radius = with(LocalDensity.current) { 680.dp.toPx() }
                        )
                    )
            )
            com.chris.m3usuite.ui.fx.FishBackground(
                modifier = Modifier.align(Alignment.Center).size(560.dp),
                alpha = 0.05f
            )
            com.chris.m3usuite.ui.common.AccentCard(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                accent = accent
            ) {
                val ftKey = remember(seasonSel, episodes.size) { (seasonSel ?: -1) to episodes.size }
                FadeThrough(key = ftKey) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        state = listState,
                        contentPadding = PaddingValues(bottom = 16.dp)
                    ) {
                        // Header (Titel, Poster, Kid‑Freigabe)
                        item {
                            Column(Modifier.fillMaxWidth()) {
                                val cleanTitle = remember(title, year) { cleanSeriesName(title, year) }
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = badgeColor,
                                    contentColor = Color.White,
                                    modifier = Modifier.graphicsLayer(alpha = DesignTokens.BadgeAlpha)
                                ) {
                                    Text(
                                        if (year != null) "$cleanTitle ($year)" else cleanTitle,
                                        style = MaterialTheme.typography.titleLarge,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    color = accent.copy(alpha = 0.35f)
                                )
                                Spacer(Modifier.height(8.dp))
                                AppAsyncImage(
                                    url = poster,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.height(220.dp).fillMaxWidth()
                                )
                                if (isAdult) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 8.dp),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        AppIconButton(
                                            icon = com.chris.m3usuite.ui.common.AppIcon.AddKid,
                                            variant = com.chris.m3usuite.ui.common.IconVariant.Solid,
                                            contentDescription = "Für Kinder freigeben",
                                            onClick = { showGrantSheet = true }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                        }

                        // Plot (expand/collapse)
                        if (!plot.isNullOrBlank()) {
                            item {
                                var plotExpanded by remember { mutableStateOf(false) }
                                val plotAnim by animateFloatAsState(
                                    if (plotExpanded) 0f else 1f,
                                    animationSpec = tween(180),
                                    label = "plotGrad"
                                )
                                Column(Modifier.animateContentSize()) {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = badgeColorDarker,
                                        contentColor = Color.White,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .graphicsLayer(alpha = DesignTokens.BadgeAlpha)
                                    ) {
                                        Text(
                                            plot!!,
                                            maxLines = if (plotExpanded) Int.MAX_VALUE else 8,
                                            modifier = Modifier.padding(12.dp)
                                        )
                                    }
                                    androidx.compose.material3.TextButton(onClick = { plotExpanded = !plotExpanded }) {
                                        Text(if (plotExpanded) "Weniger anzeigen" else "Mehr anzeigen")
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                            }
                        }

                        // Staffeln – reines Umschalten (lokales Filtern)
                        if (seasons.isNotEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = badgeColor,
                                    contentColor = Color.White,
                                    modifier = Modifier.graphicsLayer(alpha = DesignTokens.BadgeAlpha)
                                ) {
                                    Text(
                                        "Staffeln",
                                        style = MaterialTheme.typography.titleMedium,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(end = 8.dp)
                                ) {
                                    items(seasons, key = { it }) { s ->
                                        FilterChip(
                                            modifier = Modifier.graphicsLayer(alpha = DesignTokens.BadgeAlpha),
                                            selected = seasonSel == s,
                                            onClick = { seasonSel = s },
                                            label = { Text("S$s") },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = badgeColor,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                        }

                        // Episodenliste der aktuellen Season
                        items(
                            items = episodes,
                            key = { "${it.seriesStreamId}-${it.season}-${it.episodeNum}" }
                        ) { e ->
                            val compositeKey = "${e.seriesStreamId}-${e.season}-${e.episodeNum}"
                            var resumeSecs by remember(compositeKey, resumeRefreshKey) { mutableStateOf<Int?>(null) }

                            // Resume (OBX)
                            LaunchedEffect(compositeKey, resumeRefreshKey) {
                                resumeSecs = withContext(Dispatchers.IO) {
                                    val sid = seriesStreamId
                                    if (sid != null) com.chris.m3usuite.data.repo.ResumeRepository(ctx)
                                        .getSeriesResume(sid, e.season, e.episodeNum)
                                    else null
                                }
                            }

                            BoxWithConstraints(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                val seriesClean = remember(title, year) { cleanSeriesName(title, year) }
                                val epName = remember(e.title, seriesClean) { cleanEpisodeTitle(e.title, seriesClean) }
                                val thumbSize = 48.dp
                                val shape = RoundedCornerShape(28.dp)
                                var epFocused by remember { mutableStateOf(false) }

                                Box(Modifier.fillMaxWidth()) {
                                    // Chip Container
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .then(
                                                if (epFocused)
                                                    Modifier.border(
                                                        width = 2.dp,
                                                        brush = Brush.linearGradient(listOf(accent, Color.Transparent)),
                                                        shape = shape
                                                    )
                                                else Modifier
                                            )
                                    ) {
                                        Surface(
                                            shape = shape,
                                            color = badgeColor,
                                            contentColor = Color.White,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .graphicsLayer(alpha = DesignTokens.BadgeAlpha)
                                                .focusScaleOnTv()
                                                .onFocusChanged { epFocused = it.isFocused || it.hasFocus }
                                                .tvClickable {
                                                    if (resumeSecs != null) playEpisode(e, fromStart = false, resumeSecs = resumeSecs)
                                                    else playEpisode(e, fromStart = true)
                                                }
                                        ) {
                                            Row(
                                                Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                // Poster Thumbnail
                                                Box(
                                                    Modifier
                                                        .size(thumbSize)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                ) {
                                                    var loaded by remember(e.poster) { mutableStateOf(false) }
                                                    val alpha by animateFloatAsState(
                                                        if (loaded) 1f else 0f,
                                                        animationSpec = tween(260),
                                                        label = "thumbFade"
                                                    )
                                                    if (!loaded)
                                                        com.chris.m3usuite.ui.fx.ShimmerBox(
                                                            modifier = Modifier.fillMaxSize(),
                                                            cornerRadius = 12.dp
                                                        )
                                                    AppAsyncImage(
                                                        url = e.poster,
                                                        contentDescription = null,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha },
                                                        onLoading = { loaded = false },
                                                        onSuccess = { loaded = true },
                                                        onError = { loaded = true }
                                                    )
                                                    // Play-Overlay bei Fokus
                                                    val vis by remember { derivedStateOf { epFocused } }
                                                    val a by animateFloatAsState(
                                                        if (vis) 1f else 0f,
                                                        animationSpec = tween(150),
                                                        label = "epPlayFade"
                                                    )
                                                    if (a > 0f) {
                                                        Box(Modifier.matchParentSize()) {
                                                            AppIconButton(
                                                                icon = com.chris.m3usuite.ui.common.AppIcon.PlayCircle,
                                                                contentDescription = "Abspielen",
                                                                onClick = {
                                                                    if (resumeSecs != null) playEpisode(e, fromStart = false, resumeSecs = resumeSecs)
                                                                    else playEpisode(e, fromStart = true)
                                                                },
                                                                modifier = Modifier.align(Alignment.Center).graphicsLayer { this.alpha = a },
                                                                size = 28.dp
                                                            )
                                                        }
                                                    }
                                                }

                                                // Zentrum: SxxEyy + Titel
                                                Row(
                                                    modifier = Modifier.weight(1f),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center
                                                ) {
                                                    Text(
                                                        "S%02dE%02d".format(e.season, e.episodeNum),
                                                        color = accent,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Spacer(Modifier.size(8.dp))
                                                    Text(
                                                        epName,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // Progress-Balken
                                    val duration = e.durationSecs ?: 0
                                    val prog = (resumeSecs ?: 0).toFloat() / (if (duration > 0) duration.toFloat() else 1f)
                                    val clamped = prog.coerceIn(0f, 1f)
                                    Canvas(Modifier.matchParentSize()) {
                                        val wPx = size.width
                                        val hPx = size.height
                                        val margin = wPx * 0.05f
                                        val start = Offset(margin, hPx - 6f)
                                        val end = Offset(wPx - margin, hPx - 6f)
                                        val fillEnd = Offset(start.x + (end.x - start.x) * clamped, start.y)
                                        // Track
                                        drawLine(
                                            color = Color.White.copy(alpha = 0.35f),
                                            start = start,
                                            end = end,
                                            strokeWidth = 3f,
                                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                                        )
                                        // Progress
                                        if (duration > 0 && (resumeSecs ?: 0) > 0) {
                                            drawLine(
                                                color = accent,
                                                start = start,
                                                end = fillEnd,
                                                strokeWidth = 3.5f,
                                                cap = androidx.compose.ui.graphics.StrokeCap.Round
                                            )
                                        }
                                    }

                                    // Progress-Tooltip bei Fokus
                                    if (epFocused) {
                                        val secs = (resumeSecs ?: 0).coerceAtLeast(0)
                                        val pct = if (duration > 0) ((secs * 100) / duration) else 0
                                        Box(Modifier.matchParentSize()) {
                                            Surface(
                                                shape = RoundedCornerShape(50),
                                                color = Color.Black.copy(alpha = 0.65f),
                                                contentColor = Color.White,
                                                modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 10.dp)
                                            ) {
                                                Text(
                                                    if (secs > 0) "Fortgesetzt bei ${fmt(secs)} (${pct}%)" else "0%",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    // Next-Hinweis (aktuell inaktiv)
                                    if (nextHintEpisodeId == e.episodeId && !nextHintText.isNullOrBlank()) {
                                        Box(Modifier.matchParentSize()) {
                                            Surface(
                                                shape = RoundedCornerShape(50),
                                                color = accent.copy(alpha = 0.85f),
                                                contentColor = Color.Black,
                                                modifier = Modifier
                                                    .align(Alignment.BottomCenter)
                                                    .padding(bottom = 6.dp)
                                            ) {
                                                Text(
                                                    nextHintText!!,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }

            // Overlay: „Sticky“-Serienbadge beim Scrollen
            val showPinned by remember {
                derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 120 }
            }
            if (showPinned) {
                val cleanTitlePinned = remember(title, year) { cleanSeriesName(title, year) }
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, top = 20.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = badgeColor,
                        contentColor = Color.White,
                        modifier = Modifier.graphicsLayer(alpha = DesignTokens.BadgeAlpha)
                    ) {
                        Text(
                            if (year != null) "$cleanTitlePinned ($year)" else cleanTitlePinned,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // Kid-Freigabe-Dialoge
            if (showGrantSheet) KidSelectSheet(
                onConfirm = { kidIds ->
                    scope.launch(Dispatchers.IO) { kidIds.forEach { kidRepo.allowBulk(it, "series", listOf(id)) } }
                    showGrantSheet = false
                },
                onDismiss = { showGrantSheet = false }
            )
            if (showRevokeSheet) KidSelectSheet(
                onConfirm = { kidIds ->
                    scope.launch(Dispatchers.IO) { kidIds.forEach { kidRepo.disallowBulk(it, "series", listOf(id)) } }
                    showRevokeSheet = false
                },
                onDismiss = { showRevokeSheet = false }
            )
        }
    }
}

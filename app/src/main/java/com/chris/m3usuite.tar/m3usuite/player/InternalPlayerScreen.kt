package com.chris.m3usuite.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.LayoutInflater
import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import android.app.PictureInPictureParams
import android.util.Rational
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.chris.m3usuite.R
import com.chris.m3usuite.data.repo.ResumeRepository
import com.chris.m3usuite.data.obx.ObxStore
import com.chris.m3usuite.data.repo.ScreenTimeRepository
import com.chris.m3usuite.prefs.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

/**
 * Interner Player (Media3) mit:
 * - Untertitel-Stil aus Settings
 * - Resume-Speicherung alle ~3s & beim Schließen
 * - optionaler Startposition
 *
 * type: "vod" | "series" | "live"  (live wird nicht persistiert)
 */
@androidx.media3.common.util.UnstableApi
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun InternalPlayerScreen(
    url: String,
    type: String,                 // "vod" | "series" | "live"
    mediaId: Long? = null,        // VOD
    episodeId: Int? = null,       // Series (legacy id)
    seriesId: Int? = null,        // Series composite
    season: Int? = null,
    episodeNum: Int? = null,
    startPositionMs: Long? = null,
    headers: Map<String, String> = emptyMap(),
    onExit: () -> Unit
) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val obxStore = remember(ctx) { ObxStore.get(ctx) }
    val resumeRepo = remember(ctx) { ResumeRepository(ctx) }
    val store = remember(ctx) { SettingsStore(ctx) }
    val screenTimeRepo = remember(ctx) { ScreenTimeRepository(ctx) }

    // Settings (Untertitel)
    val subScale by store.subtitleScale.collectAsStateWithLifecycle(initialValue = 0.06f)
    val subFg by store.subtitleFg.collectAsStateWithLifecycle(initialValue = 0xF2FFFFFF.toInt())
    val subBg by store.subtitleBg.collectAsStateWithLifecycle(initialValue = 0x66000000)
    val subFgOpacity by store.subtitleFgOpacityPct.collectAsStateWithLifecycle(initialValue = 90)
    val subBgOpacity by store.subtitleBgOpacityPct.collectAsStateWithLifecycle(initialValue = 40)
    val rotationLocked by store.rotationLocked.collectAsStateWithLifecycle(initialValue = false)
    val autoplayNext by store.autoplayNext.collectAsStateWithLifecycle(initialValue = false)

    // HTTP Factory mit Headern
    val extraJson by store.extraHeadersJson.collectAsStateWithLifecycle(initialValue = "")
    val mergedHeaders = remember(headers, extraJson) {
        val extras = com.chris.m3usuite.core.http.RequestHeadersProvider.parseExtraHeaders(extraJson)
        com.chris.m3usuite.core.http.RequestHeadersProvider.merge(headers, extras)
    }
    val httpFactory = remember(mergedHeaders) {
        val ua = mergedHeaders["User-Agent"] ?: "IBOPlayer/1.4 (Android)"
        val props = HashMap<String, String>(mergedHeaders)
        if (!props.containsKey("Accept")) props["Accept"] = "*/*"
        runCatching {
            android.util.Log.d(
                "PlayerHTTP",
                "prepare ua=\"${ua ?: ""}\" ref=\"${props["Referer"] ?: ""}\" accept=\"${props["Accept"] ?: ""}\""
            )
        }
        DefaultHttpDataSource.Factory()
            .apply { if (!ua.isNullOrBlank()) setUserAgent(ua) }
            .setAllowCrossProtocolRedirects(true)
            .apply { if (props.isNotEmpty()) setDefaultRequestProperties(props) }
    }
    val dataSourceFactory = remember(httpFactory, ctx) {
        val base = DefaultDataSource.Factory(ctx, httpFactory)
        // Prefer TDLib streaming; fallback routing handles local-file cases
        com.chris.m3usuite.telegram.TelegramTdlibDataSource.Factory(ctx, base)
    }

    // Player
    val exoPlayer = remember(url, headers, dataSourceFactory) {
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(
                androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSourceFactory)
            )
            .build()
            .apply {
                setMediaItem(MediaItem.fromUri(url))
                prepare()
                playWhenReady = false // Phase 4: erst nach Screen-Time-Check starten
                startPositionMs?.let { seekTo(it) }
            }
    }

    // Phase 4: Kid-Profil + Screen-Time-Gate vor Start
    var kidBlocked by remember { mutableStateOf(false) }
    var kidActive by remember { mutableStateOf(false) }
    var kidIdState by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(Unit) {
        try {
            val id = store.currentProfileId.first()
            if (id > 0) {
                val prof = withContext(Dispatchers.IO) { obxStore.boxFor(com.chris.m3usuite.data.obx.ObxProfile::class.java).get(id) }
                kidActive = prof?.type == "kid"
                kidIdState = if (kidActive) id else null
            }
            if (kidActive) {
                val remain = screenTimeRepo.remainingMinutes(kidIdState!!)
                kidBlocked = remain <= 0
            }
            if (!kidBlocked) {
                exoPlayer.playWhenReady = true
            }
        } catch (_: Throwable) {
            exoPlayer.playWhenReady = true
        }
    }

    // resume: load (seek to saved position if available and >10s)
    LaunchedEffect(type, mediaId, episodeId, seriesId, season, episodeNum, exoPlayer) {
        if ((type == "vod" && mediaId != null) || (type == "series" && (episodeId != null || (seriesId != null && season != null && episodeNum != null)))) {
            try {
                if (startPositionMs == null) {
                    val posSecs = withContext(Dispatchers.IO) {
                        if (type == "vod") resumeRepo.recentVod(1).firstOrNull { it.mediaId == mediaId }?.positionSecs else if (seriesId != null && season != null && episodeNum != null) {
                            resumeRepo.recentEpisodes(50).firstOrNull { it.seriesId == seriesId && it.season == season && it.episodeNum == episodeNum }?.positionSecs
                        } else null
                    }
                    val p = (posSecs ?: 0)
                    if (p > 10) {
                        exoPlayer.seekTo(p.toLong() * 1000L)
                    }
                }
            } catch (_: Throwable) {
                // ignore, best-effort
            }
        }
    }

    // Lifecycle: Pause/Resume/Release + resume: clear/save on destroy
    DisposableEffect(lifecycleOwner, exoPlayer) {
        val obs = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    // Don't pause when entering Picture-in-Picture
                    val act = ctx as? Activity
                    if (act?.isInPictureInPictureMode != true) {
                        exoPlayer.playWhenReady = false
                    }
                }
                Lifecycle.Event.ON_RESUME -> exoPlayer.playWhenReady = true
                Lifecycle.Event.ON_DESTROY -> {
                    // resume: clear if near end (<10s), otherwise save
                    runBlocking {
                        try {
                            if (type != "live") {
                                val dur = exoPlayer.duration
                                val pos = exoPlayer.currentPosition
                                val remaining = if (dur > 0) dur - pos else Long.MAX_VALUE
                                if ((type == "vod" && mediaId != null) || (type == "series" && (seriesId != null && season != null && episodeNum != null))) {
                                    if (dur > 0 && remaining in 0..9999) {
                                        withContext(Dispatchers.IO) {
                                            if (type == "vod") resumeRepo.clearVod(mediaId!!) else Unit
                                        }
                                    } else {
                                        withContext(Dispatchers.IO) {
                                            val posSecs = (pos / 1000L).toInt().coerceAtLeast(0)
                                            if (type == "vod" && mediaId != null) resumeRepo.setVodResume(mediaId, posSecs) else if (type == "series" && (seriesId != null && season != null && episodeNum != null)) {
                                                resumeRepo.setSeriesResume(seriesId, season, episodeNum, posSecs)
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (_: Throwable) {
                        }
                    }
                    exoPlayer.release()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // Rotation-Lock nur in diesem Screen anwenden/aufheben
    DisposableEffect(rotationLocked) {
        val activity = (ctx as? Activity)
        val prev = activity?.requestedOrientation
        if (rotationLocked) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        onDispose {
            if (rotationLocked) {
                activity?.requestedOrientation = prev ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    // resume: save/clear periodically (~3s) + Phase 4: Screen-Time tick (Kids)
    LaunchedEffect(url, type, mediaId, episodeId, exoPlayer) {
        var tickAccum = 0
        while (isActive) {
            try {
                if ((type == "vod" && mediaId != null) || (type == "series" && seriesId != null && season != null && episodeNum != null)) {
                    val dur = exoPlayer.duration
                    val pos = exoPlayer.currentPosition
                    val remaining = if (dur > 0) dur - pos else Long.MAX_VALUE
                    if (dur > 0 && remaining in 0..9999) {
                        withContext(Dispatchers.IO) {
                            if (type == "vod") resumeRepo.clearVod(mediaId!!) else resumeRepo.clearSeriesResume(seriesId!!, season!!, episodeNum!!)
                        }
                    } else if (type != "live") {
                        val posSecs = (pos / 1000L).toInt().coerceAtLeast(0)
                        withContext(Dispatchers.IO) {
                            if (type == "vod" && mediaId != null) resumeRepo.setVodResume(mediaId, posSecs) else resumeRepo.setSeriesResume(seriesId!!, season!!, episodeNum!!, posSecs)
                        }
                    }
                }

                // Screen-Time: alle 60s Verbrauch ticken und Limit prüfen (nur Kids)
                if (kidActive && exoPlayer.playWhenReady && exoPlayer.isPlaying) {
                    tickAccum += 3
                    if (tickAccum >= 60) {
                        val kidId = kidIdState
                        if (kidId != null) {
                            screenTimeRepo.tickUsageIfPlaying(kidId, tickAccum)
                            tickAccum = 0
                            val remain = screenTimeRepo.remainingMinutes(kidId)
                            if (remain <= 0) {
                                exoPlayer.playWhenReady = false
                                kidBlocked = true
                            }
                        } else {
                            tickAccum = 0
                        }
                    }
                } else {
                    tickAccum = 0
                }
            } catch (_: Throwable) {
            }
            delay(3000)
        }
    }

    // resume: clear on playback ended
    DisposableEffect(exoPlayer, type, mediaId, episodeId) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    if ((type == "vod" && mediaId != null) || (type == "series" && seriesId != null && season != null && episodeNum != null)) {
                        scope.launch(Dispatchers.IO) {
                            try {
                                if (type == "vod") resumeRepo.clearVod(mediaId!!) else resumeRepo.clearSeriesResume(seriesId!!, season!!, episodeNum!!)
                            } catch (_: Throwable) {}
                        }
                    }
                    // Phase 5: autoplay next for series
                    if (type == "series" && (seriesId != null && season != null && episodeNum != null) && autoplayNext) {
                        scope.launch(Dispatchers.IO) {
                            try {
                                val box = obxStore.boxFor(com.chris.m3usuite.data.obx.ObxEpisode::class.java)
                                val curSeason = season
                                val curEp = episodeNum
                                val q = box.query(
                                    com.chris.m3usuite.data.obx.ObxEpisode_.seriesId.equal(seriesId.toLong())
                                ).build()
                                val list = q.find().sortedWith(compareBy<com.chris.m3usuite.data.obx.ObxEpisode> { it.season }.thenBy { it.episodeNum })
                                val idx = list.indexOfFirst { it.season == curSeason && it.episodeNum == curEp }
                                val next = if (idx >= 0 && idx + 1 < list.size) list[idx + 1] else null
                                if (next != null) {
                                    val snap = store.snapshot()
                                    val scheme = if (snap.xtPort == 443) "https" else "http"
                                    val http = com.chris.m3usuite.core.http.HttpClientFactory.create(ctx, store)
                                    val client = com.chris.m3usuite.core.xtream.XtreamClient(http)
                                    val caps = com.chris.m3usuite.core.xtream.ProviderCapabilityStore(ctx)
                                    val ports = com.chris.m3usuite.core.xtream.EndpointPortStore(ctx)
                                    client.initialize(scheme, snap.xtHost, snap.xtUser, snap.xtPass, basePath = null, store = caps, portStore = ports, portOverride = snap.xtPort)
                                    val nextUrl = client.buildSeriesEpisodePlayUrl(seriesId, next.season, next.episodeNum, next.playExt)
                                    withContext(Dispatchers.Main) {
                                        exoPlayer.setMediaItem(MediaItem.fromUri(nextUrl))
                                        exoPlayer.prepare()
                                        exoPlayer.playWhenReady = true
                                    }
                                }
                            } catch (_: Throwable) {}
                        }
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Auto-save resume on exit without prompting
    var confirmExit by remember { mutableStateOf(false) } // retained no-op
    var discardResume by remember { mutableStateOf(false) } // retained no-op
    var finishing by remember { mutableStateOf(false) }

    fun finishAndRelease() {
        if (finishing) return
        // Auto-save resume without confirmation
        val dur = exoPlayer.duration
        val pos = exoPlayer.currentPosition
        finishing = true
        scope.launch(Dispatchers.IO) {
            try {
                if (type != "live" && ((type == "vod" && mediaId != null) || (type == "series" && episodeId != null))) {
                    val remaining = if (dur > 0) dur - pos else Long.MAX_VALUE
                    if (dur > 0 && remaining in 0..9999) {
                        if (type == "vod") resumeRepo.clearVod(mediaId!!) else Unit
                    } else {
                        val posSecs = (pos / 1000L).toInt().coerceAtLeast(0)
                        if (type == "vod" && mediaId != null) resumeRepo.setVodResume(mediaId, posSecs)
                    }
                }
            } catch (_: Throwable) {}
            withContext(Dispatchers.Main) {
                try { exoPlayer.release() } catch (_: Throwable) {}
                onExit()
            }
        }
    }

    BackHandler { finishAndRelease() }

    // Phase 6: Subtitle/CC menu (Adult only)
    var showCcMenu by remember { mutableStateOf(false) }
    val isAdult = !kidActive

    // Local, session-only overrides applied immediately (persist optional)
    var localScale by remember { mutableStateOf<Float?>(null) }
    var localFg by remember { mutableStateOf<Int?>(null) }
    var localBg by remember { mutableStateOf<Int?>(null) }
    var localFgOpacity by remember { mutableStateOf<Int?>(null) }
    var localBgOpacity by remember { mutableStateOf<Int?>(null) }

    fun effectiveScale(): Float = localScale ?: subScale
    fun effectiveFg(): Int = localFg ?: subFg
    fun effectiveBg(): Int = localBg ?: subBg
    fun effectiveFgOpacity(): Int = localFgOpacity ?: subFgOpacity
    fun effectiveBgOpacity(): Int = localBgOpacity ?: subBgOpacity

    data class SubOpt(val label: String, val groupIndex: Int?, val trackIndex: Int?)
    var subOptions by remember { mutableStateOf(listOf<SubOpt>()) }
    var selectedSub by remember { mutableStateOf<SubOpt?>(null) }
    data class AudioOpt(val label: String, val groupIndex: Int?, val trackIndex: Int?)
    var audioOptions by remember { mutableStateOf(listOf<AudioOpt>()) }
    var selectedAudio by remember { mutableStateOf<AudioOpt?>(null) }

    fun refreshSubtitleOptions() {
        val tracks: Tracks = exoPlayer.currentTracks
        val opts = mutableListOf<SubOpt>()
        opts += SubOpt("Aus", null, null)
        var currentSel: SubOpt? = null
        tracks.groups.forEachIndexed { gi, g ->
            if (g.type == C.TRACK_TYPE_TEXT) {
                for (ti in 0 until g.length) {
                    val fmt = g.getTrackFormat(ti)
                    val lang = fmt.language?.uppercase() ?: ""
                    val base = fmt.label ?: (if (lang.isNotBlank()) "Untertitel $lang" else "Untertitel ${gi}-${ti}")
                    val label = if (lang.isNotBlank() && !base.contains("[$lang]")) "$base [$lang]" else base
                    val opt = SubOpt(label, gi, ti)
                    opts += opt
                    if (g.isTrackSelected(ti)) currentSel = opt
                }
            }
        }
        subOptions = opts
        selectedSub = currentSel ?: opts.firstOrNull()
    }

    fun refreshAudioOptions() {
        val tracks: Tracks = exoPlayer.currentTracks
        val opts = mutableListOf<AudioOpt>()
        opts += AudioOpt("Auto", null, null)
        var currentSel: AudioOpt? = null
        tracks.groups.forEachIndexed { gi, g ->
            if (g.type == C.TRACK_TYPE_AUDIO) {
                for (ti in 0 until g.length) {
                    val fmt = g.getTrackFormat(ti)
                    val lang = fmt.language?.uppercase() ?: ""
                    val ch = if (fmt.channelCount != androidx.media3.common.Format.NO_VALUE) "${fmt.channelCount}ch" else ""
                    val br = if (fmt.averageBitrate != androidx.media3.common.Format.NO_VALUE) "${fmt.averageBitrate/1000}kbps" else ""
                    val base0 = fmt.label ?: (if (lang.isNotBlank()) "Audio $lang" else "Audio ${gi}-${ti}")
                    val base = if (lang.isNotBlank() && !base0.contains("[$lang]")) "$base0 [$lang]" else base0
                    val meta = listOf(ch, br).filter { it.isNotBlank() }.joinToString(" · ")
                    val label = if (meta.isNotBlank()) "$base ($meta)" else base
                    val opt = AudioOpt(label, gi, ti)
                    opts += opt
                    if (g.isTrackSelected(ti)) currentSel = opt
                }
            }
        }
        audioOptions = opts
        selectedAudio = currentSel ?: opts.firstOrNull()
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                refreshSubtitleOptions()
                refreshAudioOptions()
            }
        }
        exoPlayer.addListener(listener)
        refreshSubtitleOptions()
        refreshAudioOptions()
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Fullscreen player with tap-to-show controls overlay
    var controlsVisible by remember { mutableStateOf(true) }
    var controlsTick by remember { mutableStateOf(0) }
    var sliderValue by remember { mutableStateOf(0f) }
    var isSeeking by remember { mutableStateOf(false) }
    var positionMs by remember { mutableStateOf(0L) }
    var durationMs by remember { mutableStateOf(0L) }
    var canSeek by remember { mutableStateOf(false) }

    // Aspect / resize controls
    var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    // Overlays: make container fully transparent (only buttons visible)
    val scrimAlpha = 0f
    val bottomScrimAlpha = 0f
    var showAspectMenu by remember { mutableStateOf(false) }
    var customScaleEnabled by remember { mutableStateOf(false) }
    var customScaleX by remember { mutableStateOf(1f) }
    var customScaleY by remember { mutableStateOf(1f) }

    fun cycleResize() {
        customScaleEnabled = false
        resizeMode = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
    }

    fun togglePlayPause() {
        val nowPlaying = exoPlayer.playWhenReady && exoPlayer.isPlaying
        exoPlayer.playWhenReady = !nowPlaying
    }

    // Update seekability from player (handles live/dynamic cases correctly)
    DisposableEffect(exoPlayer) {
        canSeek = exoPlayer.isCurrentMediaItemSeekable
        val listener = object : Player.Listener {
            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                canSeek = exoPlayer.isCurrentMediaItemSeekable
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                canSeek = exoPlayer.isCurrentMediaItemSeekable
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                canSeek = exoPlayer.isCurrentMediaItemSeekable
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Auto-hide controls after 3 seconds when visible and no modal open
    LaunchedEffect(controlsVisible, controlsTick, showCcMenu, showAspectMenu) {
        if (controlsVisible && !showCcMenu && !showAspectMenu) {
            delay(3000)
            controlsVisible = false
        }
    }

    

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    if (customScaleEnabled) {
                        scaleX = customScaleX.coerceIn(0.5f, 2.0f)
                        scaleY = customScaleY.coerceIn(0.5f, 2.0f)
                    }
                },
            factory = { LayoutInflater.from(ctx).inflate(R.layout.compose_player_view, null, false) as PlayerView },
            update = { view ->
                view.player = exoPlayer
                view.useController = false
                view.resizeMode = resizeMode
                // Ensure view can receive media keys
                try {
                    view.isFocusable = true
                    view.isFocusableInTouchMode = true
                    view.requestFocus()
                    view.setOnKeyListener { _, keyCode, event ->
                        if (event.action != android.view.KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                        when (keyCode) {
                            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                            android.view.KeyEvent.KEYCODE_SPACE,
                            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
                            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
                            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                                togglePlayPause(); true
                            }
                            else -> false
                        }
                    }
                } catch (_: Throwable) {}
                view.subtitleView?.apply {
                    setApplyEmbeddedStyles(true)
                    setApplyEmbeddedFontSizes(true)
                    setFractionalTextSize(effectiveScale())

                    val fg = withOpacity(effectiveFg(), effectiveFgOpacity())
                    val bg = withOpacity(effectiveBg(), effectiveBgOpacity())
                    val style = CaptionStyleCompat(
                        fg,
                        bg,
                        0x00000000, // windowColor transparent
                        CaptionStyleCompat.EDGE_TYPE_NONE,
                        0x00000000,
                        /* typeface = */ null
                    )
                    setStyle(style)
                }
            }
        )

        // Tap catcher to toggle controls
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onTap = { controlsVisible = !controlsVisible; if (controlsVisible) controlsTick++ }) }
        )

        // Controls overlay
        if (controlsVisible) Popup(
            alignment = Alignment.Center,
            properties = PopupProperties(focusable = false, dismissOnBackPress = false, usePlatformDefaultWidth = false)
        ) {
            Box(Modifier.fillMaxSize()) {
                // Top seekbar + close (80% opacity)
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = { finishAndRelease() }) {
                        Icon(
                            painter = painterResource(android.R.drawable.ic_menu_close_clear_cancel),
                            contentDescription = "Schließen",
                            tint = Color.White.copy(alpha = 0.8f)
                        )
                    }
                    if (canSeek) {
                        LaunchedEffect(Unit) {
                            while (true) {
                                durationMs = exoPlayer.duration.coerceAtLeast(0)
                                positionMs = exoPlayer.currentPosition.coerceAtLeast(0)
                                if (!isSeeking && durationMs > 0) sliderValue = (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                                delay(250)
                            }
                        }
                        androidx.compose.material3.Slider(
                            value = sliderValue,
                            onValueChange = { isSeeking = true; sliderValue = it; controlsTick++ },
                            onValueChangeFinished = {
                                val target = (sliderValue * durationMs).toLong().coerceIn(0L, durationMs)
                                exoPlayer.seekTo(target)
                                isSeeking = false
                                controlsTick++
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Center controls (transparent container)
                Row(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        val pos = exoPlayer.currentPosition
                        exoPlayer.seekTo((pos - 10_000L).coerceAtLeast(0L))
                    }) { Icon(painter = painterResource(android.R.drawable.ic_media_rew), contentDescription = "-10s", tint = Color.White.copy(alpha = 0.8f)) }
                    IconButton(onClick = { val playing = exoPlayer.playWhenReady && exoPlayer.isPlaying; exoPlayer.playWhenReady = !playing }) {
                        val icon = if (exoPlayer.playWhenReady && exoPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                        Icon(painter = painterResource(icon), contentDescription = "Play/Pause", tint = Color.White.copy(alpha = 0.8f))
                    }
                    IconButton(onClick = {
                        val pos = exoPlayer.currentPosition
                        val dur = exoPlayer.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                        exoPlayer.seekTo((pos + 10_000L).coerceAtMost(dur))
                    }) { Icon(painter = painterResource(android.R.drawable.ic_media_ff), contentDescription = "+10s", tint = Color.White.copy(alpha = 0.8f)) }
                }

                // Bottom-right icon-only tiles (70% opacity, colored)
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                        .navigationBarsPadding(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OverlayIconButton(
                        iconRes = android.R.drawable.ic_menu_slideshow,
                        containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.7f),
                        contentColor = Color.White
                    ) {
                        (ctx as? Activity)?.let { act ->
                            val params = PictureInPictureParams.Builder()
                                .setAspectRatio(Rational(16, 9))
                                .build()
                            act.enterPictureInPictureMode(params)
                        }
                    }
                    OverlayIconButton(
                        iconRes = android.R.drawable.ic_menu_sort_by_size,
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                        contentColor = Color.White
                    ) {
                        if (!showCcMenu) {
                            localScale = effectiveScale(); localFg = effectiveFg(); localBg = effectiveBg();
                            localFgOpacity = effectiveFgOpacity(); localBgOpacity = effectiveBgOpacity();
                            refreshSubtitleOptions()
                        }
                        showCcMenu = true
                    }
                    OverlayIconButton(
                        iconRes = android.R.drawable.ic_menu_crop,
                        containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f),
                        contentColor = Color.White,
                        onLongClick = { showAspectMenu = true }
                    ) {
                        customScaleEnabled = false
                        cycleResize()
                    }
                }
            }
        }
        }

        if (kidBlocked && kidActive) {
                    AlertDialog(
                        onDismissRequest = { /* block */ },
                        title = { Text("Limit erreicht") },
                        text = { Text("Das Screen-Time-Limit für heute ist aufgebraucht.") },
                        confirmButton = {
                            TextButton(onClick = { finishAndRelease() }) { Text("OK") }
                        }
                    )
        }
        // No exit confirmation; resume is always auto-saved/cleared per logic above

        if (showCcMenu && isAdult) {
                    ModalBottomSheet(onDismissRequest = { showCcMenu = false }) {
                        // Audio + Subtitle options + live style controls (scrollable)
                        Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                            Text("Audio")
                            Spacer(Modifier.padding(4.dp))
                            audioOptions.forEach { opt ->
                                val selected = selectedAudio == opt
                                Button(onClick = {
                                    selectedAudio = opt
                                    val builder = exoPlayer.trackSelectionParameters.buildUpon()
                                    builder.clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                    builder.setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                    if (opt.groupIndex != null && opt.trackIndex != null) {
                                        val group = exoPlayer.currentTracks.groups[opt.groupIndex]
                                        val override = TrackSelectionOverride(group.mediaTrackGroup, listOf(opt.trackIndex))
                                        builder.addOverride(override)
                                    }
                                    exoPlayer.trackSelectionParameters = builder.build()
                                }) { Text((if (selected) "• " else "") + opt.label) }
                                Spacer(Modifier.padding(2.dp))
                            }

                            Spacer(Modifier.padding(8.dp))
                            HorizontalDivider()
                            Spacer(Modifier.padding(8.dp))

                            Text("Untertitel",)
                            Spacer(Modifier.padding(4.dp))
                            // Track selection
                            subOptions.forEach { opt ->
                                val selected = selectedSub == opt
                                Button(onClick = {
                                    selectedSub = opt
                                    val builder = exoPlayer.trackSelectionParameters.buildUpon()
                                    if (opt.groupIndex == null) {
                                        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                        builder.clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                    } else {
                                        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                        builder.clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                        val group = exoPlayer.currentTracks.groups[opt.groupIndex]
                                        val override = TrackSelectionOverride(group.mediaTrackGroup, listOf(opt.trackIndex!!))
                                        builder.addOverride(override)
                                    }
                                    exoPlayer.trackSelectionParameters = builder.build()
                                }, enabled = true) {
                                    Text((if (selected) "• " else "") + (opt.label))
                                }
                                Spacer(Modifier.padding(2.dp))
                            }

                            Spacer(Modifier.padding(8.dp))
                            Text("Größe: ${String.format("%.2f", effectiveScale())}")
                            Slider(value = effectiveScale(), onValueChange = { v -> localScale = v }, valueRange = 0.04f..0.12f, steps = 8)

                            Text("Text-Deckkraft: ${effectiveFgOpacity()}%")
                            Slider(value = effectiveFgOpacity().toFloat(), onValueChange = { v -> localFgOpacity = v.toInt().coerceIn(0,100) }, valueRange = 0f..100f, steps = 10)

                            Text("Hintergrund-Deckkraft: ${effectiveBgOpacity()}%")
                            Slider(value = effectiveBgOpacity().toFloat(), onValueChange = { v -> localBgOpacity = v.toInt().coerceIn(0,100) }, valueRange = 0f..100f, steps = 10)

                            Spacer(Modifier.padding(8.dp))
                            // Quick presets
                            Text("Presets")
                            Row { 
                                Button(onClick = { localScale = 0.05f }) { Text("Klein") }
                                Spacer(Modifier.padding(4.dp))
                                Button(onClick = { localScale = 0.06f }) { Text("Standard") }
                                Spacer(Modifier.padding(4.dp))
                                Button(onClick = { localScale = 0.08f }) { Text("Groß") }
                            }
                            Spacer(Modifier.padding(4.dp))
                            Row { Button(onClick = { localFg = 0xFFFFFFFF.toInt(); localBg = 0x66000000 }) { Text("Hell auf dunkel") }; Spacer(Modifier.padding(4.dp)); Button(onClick = { localFg = 0xFF000000.toInt(); localBg = 0x66FFFFFF }) { Text("Dunkel auf hell") } }
                            Spacer(Modifier.padding(4.dp))
                            Row { Button(onClick = { localBg = 0x66000000 }) { Text("BG Schwarz") }; Spacer(Modifier.padding(4.dp)); Button(onClick = { localBg = 0x66FFFFFF }) { Text("BG Weiß") } }

                            Spacer(Modifier.padding(8.dp))
                            Row {
                                Button(onClick = { showCcMenu = false }) { Text("Schließen") }
                                Spacer(Modifier.padding(8.dp))
                                Button(onClick = {
                                    // Persist as default
                                    localScale?.let { scope.launch { store.setFloat(com.chris.m3usuite.prefs.Keys.SUB_SCALE, it) } }
                                    localFg?.let { scope.launch { store.setInt(com.chris.m3usuite.prefs.Keys.SUB_FG, it) } }
                                    localBg?.let { scope.launch { store.setInt(com.chris.m3usuite.prefs.Keys.SUB_BG, it) } }
                                    localFgOpacity?.let { scope.launch { store.setSubtitleFgOpacityPct(it) } }
                                    localBgOpacity?.let { scope.launch { store.setSubtitleBgOpacityPct(it) } }
                                    showCcMenu = false
                                }) { Text("Als Standard speichern") }
                            }
                }
            }
            // Bottom controls now rendered inside the consolidated popup above

            if (showAspectMenu) {
                ModalBottomSheet(onDismissRequest = { showAspectMenu = false }) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Bildformat", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; customScaleEnabled = false }) { Text("Original") }
                            Button(onClick = { resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM; customScaleEnabled = false }) { Text("Vollbild") }
                            Button(onClick = { resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL; customScaleEnabled = false }) { Text("Stretch") }
                        }
                        Spacer(Modifier.padding(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Custom")
                            androidx.compose.material3.Switch(checked = customScaleEnabled, onCheckedChange = { enabled ->
                                customScaleEnabled = enabled
                                if (enabled) resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            })
                        }
                        if (customScaleEnabled) {
                            Text("Horizontal: ${String.format("%.2f", customScaleX)}x")
                            Slider(value = customScaleX, onValueChange = { customScaleX = it }, valueRange = 0.5f..2.0f, steps = 10)
                            Text("Vertikal: ${String.format("%.2f", customScaleY)}x")
                            Slider(value = customScaleY, onValueChange = { customScaleY = it }, valueRange = 0.5f..2.0f, steps = 10)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { customScaleX = 1f; customScaleY = 1f }) { Text("Reset") }
                            }
                        }
                        Row(Modifier.padding(top = 8.dp)) {
                            Button(onClick = { showAspectMenu = false }) { Text("Schließen") }
                        }
                    }
                }
            }
        }
    }
// helper: apply opacity to ARGB color
private fun withOpacity(argb: Int, percent: Int): Int {
    val p = percent.coerceIn(0, 100)
    val a = (p / 100f * 255f).toInt().coerceIn(0, 255)
    val rgb = argb and 0x00FFFFFF
    return (a shl 24) or rgb
}

// helper: format milliseconds to mm:ss or hh:mm:ss
private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val total = ms / 1000
    val s = (total % 60).toInt()
    val m = ((total / 60) % 60).toInt()
    val h = (total / 3600).toInt()
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
}

@Composable
private fun OverlayActionTile(
    @DrawableRes iconRes: Int,
    label: String,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.elevatedCardElevation(),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
            contentColor = contentColorFor(MaterialTheme.colorScheme.surface)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(painter = painterResource(iconRes), contentDescription = null)
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun OverlayIconButton(
    @DrawableRes iconRes: Int,
    containerColor: Color,
    contentColor: Color,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val shape = MaterialTheme.shapes.large
    val modifier = if (onLongClick != null) {
        Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)
    } else Modifier.then(Modifier.clickable(onClick = onClick))
    ElevatedCard(
        onClick = onClick,
        shape = shape,
        elevation = CardDefaults.elevatedCardElevation(),
        colors = CardDefaults.elevatedCardColors(containerColor = containerColor, contentColor = contentColor),
        modifier = modifier
    ) {
        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(painter = painterResource(iconRes), contentDescription = null, tint = contentColor)
        }
    }
}

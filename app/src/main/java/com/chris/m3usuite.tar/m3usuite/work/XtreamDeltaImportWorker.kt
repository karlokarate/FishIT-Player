package com.chris.m3usuite.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.Constraints
import java.util.concurrent.TimeUnit
import com.chris.m3usuite.prefs.SettingsStore
import com.chris.m3usuite.data.repo.XtreamObxRepository
import com.chris.m3usuite.data.obx.ObxStore
import kotlinx.coroutines.flow.first

class XtreamDeltaImportWorker(appContext: Context, params: WorkerParameters): CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val store = SettingsStore(ctx)
        val hasXt = store.hasXtream()
        if (!hasXt) return Result.success()
        return try {
            val repo = XtreamObxRepository(ctx, store)
            // Quick seed for immediate UI visibility (small batch, no details)
            runCatching { repo.seedListsQuick(limitPerKind = 200) }
            // Full delta import (with details + orphan cleanup); expected to use batched puts internally
            val res = repo.importDelta(deleteOrphans = true)
            // clean thread-locals after heavy OBX activity inside the repo
            runCatching { ObxStore.get(ctx).closeThreadResources() }
            if (res.isSuccess) Result.success() else Result.retry()
        } catch (_: Throwable) {
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE = "xtream_delta_import"

        fun schedulePeriodic(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .setRequiresCharging(true)
                .build()
            val req = PeriodicWorkRequestBuilder<XtreamDeltaImportWorker>(12, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(UNIQUE, ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun triggerOnce(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val req = OneTimeWorkRequestBuilder<XtreamDeltaImportWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniqueWork("${UNIQUE}_once", ExistingWorkPolicy.REPLACE, req)
        }
    }
}

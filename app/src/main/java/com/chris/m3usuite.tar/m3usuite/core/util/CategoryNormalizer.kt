package com.chris.m3usuite.core.util

/**
 * CategoryNormalizer (core)
 *
 * Normalizes potentially noisy provider/category strings into stable keys
 * and provides a human-friendly display label.
 *
 * This is a relocation of the previous ui.util.CategoryNormalizer to fix
 * a layering violation (data/work must not depend on ui).
 */
object CategoryNormalizer {

    private val leadingLang = Regex("^(?:[A-Z]{2,3})\\s*\\|\\s*")
    private val nonWord = Regex("[^\\p{L}\\p{N}]+")
    private val ws = Regex("\\s+")

    /**
     * Convert a raw category/provider string to a normalized key.
     * Examples:
     *  - "DE | Netflix" -> "netflix"
     *  - "Disney Plus"  -> "disney_plus"
     *  - "Apple TV+"    -> "apple_tv_plus"
     *  - "4K Movies"    -> "4k_movies"
     */
    fun normalizeKey(raw: String?): String {
        if (raw.isNullOrBlank()) return "unknown"
        var s = raw.trim()
        s = leadingLang.replace(s, "") // drop leading country/ALL prefixes like "DE | "

        val lower = s.lowercase()

        // Common OTT brands (return canonical slugs)
        if ("apple" in lower) return "apple_tv_plus"
        if ("netflix" in lower) return "netflix"
        if ("disney" in lower) return "disney_plus"
        if ("prime" in lower || "amazon" in lower) return "amazon_prime"
        if ("paramount" in lower) return "paramount_plus"
        if ("hbo" in lower || Regex(".*\\bmax\\b.*").containsMatchIn(lower)) return "max"
        if ("sky" in lower || Regex("\\bwow\\b").containsMatchIn(lower)) return "sky_wow"
        if ("discovery" in lower) return "discovery_plus"
        if ("mubi" in lower) return "mubi"

        // Theme buckets
        if ("kids" in lower || "kinder" in lower || "cartoon" in lower || "animation" in lower) return "kids"
        if ("sport" in lower || "sports" in lower || "fussball" in lower || "football" in lower) return "sports"
        if ("news" in lower || "nachrichten" in lower) return "news"
        if ("music" in lower || "musik" in lower) return "music"
        if ("documentary" in lower || "dokumentation" in lower || "doku" in lower) return "documentary"

        // Fallback: sanitize to snake_case
        val base = nonWord.replace(lower, "_").trim('_')
        return base.ifBlank { "unknown" }
    }

    /**
     * Convert a normalized key to a human-readable label.
     */
    fun displayLabel(key: String): String = when (key) {
        "apple_tv_plus" -> "Apple TV+"
        "netflix" -> "Netflix"
        "disney_plus" -> "Disney+"
        "amazon_prime" -> "Amazon Prime"
        "paramount_plus" -> "Paramount+"
        "max" -> "Max"
        "sky_wow" -> "Sky / WOW"
        "discovery_plus" -> "discovery+"
        "mubi" -> "MUBI"
        "kids" -> "Kids"
        "sports" -> "Sport"
        "news" -> "News"
        "music" -> "Musik"
        "documentary" -> "Dokumentationen"
        "unknown" -> "Unbekannt"
        else -> key.replace("_", " ").replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}

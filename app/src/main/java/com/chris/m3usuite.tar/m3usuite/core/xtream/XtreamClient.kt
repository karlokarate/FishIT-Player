package com.chris.m3usuite.core.xtream

import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * XtreamClient – API‑first Client für Xtream Codes Panels.
 *
 * Unterschied zu älteren Ständen:
 *  - Wenn **keine Kategorie** übergeben wird, wird bei Listen-Calls zunächst **category_id=*** gefragt
 *    und **nur bei leerem Ergebnis oder Fehler** auf **category_id=0** gefallen (deckt beide Panel‑Varianten ab).
 *  - JSON‑Helper werden **aktiv genutzt** (isJsonArray/isJsonObject), keine „immer true“-Heuristik.
 *  - EPG‑Prefetch im Client bleibt erhalten, ist aber **@Deprecated** – nutze bitte
 *    `EpgRepository.prefetchNowNext(...)`, da dort Cache & Persist bereits integriert sind.
 */
class XtreamClient(
    private val http: OkHttpClient,
    private val json: Json = Json { ignoreUnknownKeys = true },
    private val io: CoroutineDispatcher = Dispatchers.IO
) {
    private lateinit var cfg: XtreamConfig
    private lateinit var caps: XtreamCapabilities
    private var vodKind: String = "vod"

    // Eigener Client für Xtream-API (keine erzwungenen SSL‑Redirects)
    private var httpClient: OkHttpClient = http

    // Moderates Parallel‑Limit (nur für fire‑and‑forget EPG‑Fetch)
    private val epgSemaphore = Semaphore(4)

    /**
     * Discovery (Port/Aliasse) → finale XtreamConfig erzeugen.
     */
    suspend fun initialize(
        scheme: String,
        host: String,
        username: String,
        password: String,
        basePath: String? = null,
        livePrefs: List<String> = listOf("m3u8", "ts"),
        vodPrefs: List<String>  = listOf("mp4", "mkv", "avi"),
        seriesPrefs: List<String> = listOf("mp4", "mkv", "avi"),
        store: ProviderCapabilityStore,
        portStore: EndpointPortStore,
        forceRefreshDiscovery: Boolean = false,
        portOverride: Int? = null,
    ) = withContext(io) {
        val discoverer = CapabilityDiscoverer(
            http = http,
            store = store,
            portStore = portStore,
            json = json
        )
        caps = if ((portOverride ?: 0) > 0) {
            val cfgExplicit = XtreamConfig(
                scheme = scheme,
                host = host,
                port = portOverride!!,
                username = username,
                password = password,
                basePath = basePath,
                liveExtPrefs = livePrefs,
                vodExtPrefs = vodPrefs,
                seriesExtPrefs = seriesPrefs,
            )
            discoverer.discover(cfgExplicit, forceRefresh = forceRefreshDiscovery)
        } else {
            discoverer.discoverAuto(
                scheme = scheme,
                host = host,
                username = username,
                password = password,
                basePath = basePath,
                forceRefresh = forceRefreshDiscovery,
            )
        }

        val u = Uri.parse(caps.baseUrl)
        val resolvedScheme = (u.scheme ?: scheme).lowercase()
        val resolvedHost = u.host ?: host
        val resolvedPort = u.port.takeIf { it > 0 } ?: if (resolvedScheme == "https") 443 else 80
        vodKind = caps.resolvedAliases.vodKind ?: "vod"

        cfg = XtreamConfig(
            scheme = resolvedScheme,
            host = resolvedHost,
            port = resolvedPort,
            username = username,
            password = password,
            pathKinds = PathKinds(liveKind = "live", vodKind = vodKind, seriesKind = "series"),
            basePath = basePath,
            liveExtPrefs = livePrefs,
            vodExtPrefs = vodPrefs,
            seriesExtPrefs = seriesPrefs,
        )

        httpClient = http.newBuilder()
            .followRedirects(true)
            .followSslRedirects(false)
            .build()
    }

    // ------------------------------------------------------------
    // Kategorien
    // ------------------------------------------------------------
    suspend fun getLiveCategories(): List<RawCategory> =
        apiArray("get_live_categories") { obj ->
            RawCategory(
                category_id = obj["category_id"]?.asString(),
                category_name = obj["category_name"]?.asString(),
            )
        }

    suspend fun getSeriesCategories(): List<RawCategory> =
        apiArray("get_series_categories") { obj ->
            RawCategory(
                category_id = obj["category_id"]?.asString(),
                category_name = obj["category_name"]?.asString(),
            )
        }

    suspend fun getVodCategories(): List<RawCategory> {
        val tried = linkedSetOf<String>()
        val order = listOf(vodKind, "vod", "movie", "movies").filter { it.isNotBlank() }
        for (alias in order) {
            if (!tried.add(alias)) continue
            val res = apiArray("get_${alias}_categories") { obj ->
                RawCategory(
                    category_id = obj["category_id"]?.asString(),
                    category_name = obj["category_name"]?.asString(),
                )
            }
            if (res.isNotEmpty()) {
                vodKind = alias
                return res
            }
        }
        return emptyList()
    }

    // ------------------------------------------------------------
    // Streams (Bulk → Client‑Slicing)
    // ------------------------------------------------------------
    suspend fun getLiveStreams(categoryId: String? = null, offset: Int, limit: Int): List<RawLiveStream> =
        sliceArray("get_live_streams", categoryId, offset, limit) { obj ->
            RawLiveStream(
                num = obj["num"]?.asIntOrNull(),
                name = obj["name"]?.asString(),
                stream_id = obj["stream_id"]?.asIntOrNull(),
                stream_icon = obj["stream_icon"]?.asString(),
                epg_channel_id = obj["epg_channel_id"]?.asString(),
                tv_archive = obj["tv_archive"]?.asIntOrNull(),
                category_id = obj["category_id"]?.asString(),
            )
        }

    suspend fun getSeries(categoryId: String? = null, offset: Int, limit: Int): List<RawSeries> =
        sliceArray("get_series", categoryId, offset, limit) { obj ->
            RawSeries(
                num = obj["num"]?.asIntOrNull(),
                name = obj["name"]?.asString(),
                series_id = obj["series_id"]?.asIntOrNull(),
                cover = obj["cover"]?.asString(),
                category_id = obj["category_id"]?.asString(),
            )
        }

    suspend fun getVodStreams(categoryId: String? = null, offset: Int, limit: Int): List<RawVod> {
        val tried = linkedSetOf<String>()
        val order = listOf(vodKind, "vod", "movie", "movies").filter { it.isNotBlank() }
        for (alias in order) {
            if (!tried.add(alias)) continue
            val res = sliceArray("get_${alias}_streams", categoryId, offset, limit) { obj ->
                RawVod(
                    num = obj["num"]?.asIntOrNull(),
                    name = obj["name"]?.asString(),
                    vod_id = (obj["vod_id"] ?: obj["movie_id"] ?: obj["id"])?.asIntOrNull(),
                    stream_icon = obj["stream_icon"]?.asString(),
                    category_id = obj["category_id"]?.asString(),
                )
            }
            if (res.isNotEmpty()) {
                vodKind = alias
                return res
            }
        }
        return emptyList()
    }

    // ------------------------------------------------------------
    // Details: VOD / Series (für Drilldown)
    // ------------------------------------------------------------
    suspend fun getVodDetailFull(vodId: Int): NormalizedVodDetail? {
        val idField = resolveVodIdField()
        val aliasOrder = listOf(vodKind, "vod", "movie", "movies").filter { it.isNotBlank() }
        var infoObj: Map<String, JsonElement>? = null
        for (alias in aliasOrder) {
            infoObj = apiObject("get_${alias}_info", extra = "&$idField=$vodId")
            if (infoObj != null) { vodKind = alias; break }
        }
        infoObj ?: return null
        val movieData = infoObj["movie_data"]?.jsonObject ?: infoObj

        val backdrops = movieData["backdrop_path"]?.jsonArray?.mapNotNull { it.asString() }.orEmpty()
        val poster = movieData["poster_path"]?.asString()
        val cover = movieData["cover"]?.asString()
        val images = buildList {
            if (poster != null) add(poster)
            if (cover != null && cover != poster) add(cover)
            addAll(backdrops)
        }

        return NormalizedVodDetail(
            vodId = vodId,
            name = movieData["name"]?.asString().orEmpty(),
            year = movieData["year"]?.asIntOrNull(),
            rating = movieData["rating"]?.asDoubleOrNull(),
            plot = movieData["plot"]?.asString(),
            genre = movieData["genre"]?.asString(),
            director = movieData["director"]?.asString(),
            cast = movieData["cast"]?.asString(),
            country = movieData["country"]?.asString(),
            releaseDate = movieData["releasedate"]?.asString(),
            imdbId = movieData["imdb_id"]?.asString(),
            tmdbId = movieData["tmdb_id"]?.asString(),
            images = images.distinct(),
            trailer = movieData["youtube_trailer"]?.asString(),
        )
    }

    suspend fun getSeriesDetailFull(seriesId: Int): NormalizedSeriesDetail? {
        val root = apiObject("get_series_info", extra = "&series_id=$seriesId") ?: return null
        val info = root["info"]?.jsonObject
        val seasonsArr = root["seasons"]?.jsonArray ?: JsonArray(emptyList())
        val episodesMap = root["episodes"]?.jsonObject ?: JsonObject(emptyMap())

        val images = buildList {
            info?.get("poster_path")?.asString()?.let { add(it) }
            info?.get("cover")?.asString()?.let { if (!contains(it)) add(it) }
            info?.get("backdrop_path")?.jsonArray?.forEach { el ->
                el.asString()?.let { if (!contains(it)) add(it) }
            }
        }

        val normalizedSeasons = mutableListOf<NormalizedSeason>()
        val seasonNumbersFromSeasons = seasonsArr.mapNotNull { it.jsonObject["season_number"]?.asIntOrNull() }
        val seasonNumbersFromEpisodes = episodesMap.keys.mapNotNull { it.toIntOrNull() }
        val seasonNumbers = (seasonNumbersFromSeasons + seasonNumbersFromEpisodes).toSet().sorted()

        for (seasonNumber in seasonNumbers) {
            val key = seasonNumber.toString()
            val episodeList = episodesMap[key]?.jsonArray ?: JsonArray(emptyList())
            val normalizedEpisodes = episodeList.mapNotNull { epEl ->
                val epObj = epEl.jsonObject
                val infoObj = epObj["info"]?.jsonObject
                NormalizedEpisode(
                    episodeNum = epObj["episode_num"]?.asIntOrNull() ?: epObj["id"]?.asIntOrNull() ?: return@mapNotNull null,
                    title = epObj["title"]?.asString(),
                    durationSecs = infoObj?.get("duration")?.asIntFromDuration(),
                    rating = infoObj?.get("rating")?.asDoubleOrNull(),
                    plot = infoObj?.get("plot")?.asString(),
                    airDate = infoObj?.get("releasedate")?.asString(),
                    playExt = epObj["container_extension"]?.asString(),
                )
            }
            normalizedSeasons += NormalizedSeason(
                seasonNumber = seasonNumber,
                episodes = normalizedEpisodes,
            )
        }

        return NormalizedSeriesDetail(
            seriesId = seriesId,
            name = info?.get("name")?.asString().orEmpty(),
            year = info?.get("year")?.asIntOrNull(),
            rating = info?.get("rating")?.asDoubleOrNull(),
            plot = info?.get("plot")?.asString(),
            genre = info?.get("genre")?.asString(),
            director = info?.get("director")?.asString(),
            cast = info?.get("cast")?.asString(),
            imdbId = info?.get("imdb_id")?.asString(),
            tmdbId = info?.get("tmdb_id")?.asString(),
            images = images.distinct(),
            trailer = info?.get("youtube_trailer")?.asString(),
            seasons = normalizedSeasons,
        )
    }

    // ------------------------------------------------------------
    // EPG – On‑Demand (sichtbare IDs)
    // ------------------------------------------------------------
    suspend fun fetchShortEpg(streamId: Int, limit: Int = 20): String? =
        apiRaw("get_short_epg", "&stream_id=$streamId&limit=$limit")

    /**
     * Veraltet: nutze stattdessen EpgRepository.prefetchNowNext(...),
     * damit Cache & Persist gepflegt werden.
     */
    @Deprecated("Use EpgRepository.prefetchNowNext(...) for caching/persistence")
    suspend fun prefetchEpgForVisible(streamIds: List<Int>, perStreamLimit: Int = 10) = withContext(io) {
        streamIds.distinct().forEach { id ->
            epgSemaphore.withPermit {
                fetchShortEpg(id, perStreamLimit) // fire‑and‑forget (kein Persist)
            }
        }
    }

    // ------------------------------------------------------------
    // Play‑URLs
    // ------------------------------------------------------------
    fun buildLivePlayUrl(streamId: Int, extOverride: String? = null): String =
        cfg.liveUrl(streamId, extOverride)

    fun buildVodPlayUrl(vodId: Int, container: String?): String =
        cfg.vodUrl(vodId, container)

    fun buildSeriesEpisodePlayUrl(seriesId: Int, season: Int, episode: Int, episodeExt: String?): String =
        cfg.seriesEpisodeUrl(seriesId, season, episode, episodeExt)

    // ============================================================
    // Internals: API Helpers
    // ============================================================
    private suspend fun <T> apiArray(
        action: String,
        extra: String? = null,
        map: (obj: Map<String, JsonElement>) -> T,
    ): List<T> = withContext(io) {
        val url = cfg.playerApi(action, extra)
        Log.i("XtreamClient", "API: $url")
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("Accept-Encoding", "gzip")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@withContext emptyList()
            val body = resp.body?.string().orEmpty()
            val root = json.parseToJsonElement(body)
            if (root.isJsonArray()) root.jsonArray.mapNotNull { el -> el.jsonObjectOrNull()?.let { map(it) } } else emptyList()
        }
    }

    private suspend fun <T> sliceArray(
        action: String,
        categoryId: String?,
        offset: Int,
        limit: Int,
        map: (obj: Map<String, JsonElement>) -> T,
    ): List<T> {
        val all: List<T> = if (categoryId == null) {
            // Erst * probieren; bei leerem Resultat ODER Fehler → 0
            val star = runCatching { apiArray(action, extra = "&category_id=*", map = map) }.getOrElse { emptyList() }
            if (star.isNotEmpty()) star else apiArray(action, extra = "&category_id=0", map = map)
        } else {
            apiArray(action, extra = "&category_id=$categoryId", map = map)
        }
        val from = offset.coerceAtLeast(0)
        val to = (offset + limit).coerceAtMost(all.size)
        return if (from < to) all.subList(from, to) else emptyList()
    }

    private suspend fun apiObject(action: String, extra: String?): Map<String, JsonElement>? = withContext(io) {
        val url = cfg.playerApi(action, extra)
        Log.i("XtreamClient", "API: $url")
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("Accept-Encoding", "gzip")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@withContext null
            val body = resp.body?.string().orEmpty()
            val root = json.parseToJsonElement(body)
            if (root.isJsonObject()) root.jsonObject else null
        }
    }

    private suspend fun apiRaw(action: String, extra: String?): String? = withContext(io) {
        val url = cfg.playerApi(action, extra)
        Log.i("XtreamClient", "API: $url")
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("Accept-Encoding", "gzip")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@withContext null
            resp.body?.string()
        }
    }

    private fun resolveVodIdField(): String = "vod_id" // die meisten Panels erwarten dieses Feld
}

// ============================================================
// JSON‑Helper (sicheres Lesen ohne NPEs)
// ============================================================
private fun JsonElement?.asString(): String? = runCatching { this?.jsonPrimitive?.content }.getOrNull()
private fun JsonElement?.asIntOrNull(): Int? = runCatching { this?.jsonPrimitive?.intOrNull }.getOrNull()
private fun JsonElement?.asDoubleOrNull(): Double? = runCatching { this?.jsonPrimitive?.doubleOrNull }.getOrNull()
private fun JsonElement?.jsonObjectOrNull(): Map<String, JsonElement>? = runCatching { this?.jsonObject }.getOrNull()

private fun JsonElement?.isJsonArray(): Boolean = this is JsonArray
private fun JsonElement?.isJsonObject(): Boolean = this is JsonObject

// "01:23:45" → Sekunden; „85“ → 85
private fun JsonElement.asIntFromDuration(): Int? = runCatching {
    val s = this.jsonPrimitive.content.trim()
    if (":" in s) {
        val p = s.split(":").map { it.toIntOrNull() ?: 0 }
        when (p.size) {
            3 -> p[0] * 3600 + p[1] * 60 + p[2]
            2 -> p[0] * 60 + p[1]
            else -> p.lastOrNull()
        }
    } else s.toIntOrNull()
}.getOrNull()

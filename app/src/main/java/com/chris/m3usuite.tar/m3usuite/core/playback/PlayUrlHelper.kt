package com.chris.m3usuite.core.playback

import android.content.Context
import com.chris.m3usuite.prefs.SettingsStore
import com.chris.m3usuite.model.MediaItem
import com.chris.m3usuite.core.http.HttpClientFactory
import com.chris.m3usuite.core.xtream.EndpointPortStore
import com.chris.m3usuite.core.xtream.ProviderCapabilityStore
import com.chris.m3usuite.core.xtream.XtreamClient
import kotlinx.coroutines.flow.first
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Gemeinsamer URL-/Header-Aufbau für Live & VOD.
 * - Beachtet Telegram-Quelle (tg://)
 * - Nutzt vorhandene URL oder baut Xtream-URLs (inkl. Port/Scheme)
 * - Liefert optionale Header (User-Agent, Referer)
 */
object PlayUrlHelper {

    data class PlayRequest(
        val url: String,
        val headers: Map<String, String> = emptyMap()
    )

    suspend fun forVod(
        context: Context,
        store: SettingsStore,
        item: MediaItem
    ): PlayRequest? = build(context, store, item, Type.VOD)

    suspend fun forLive(
        context: Context,
        store: SettingsStore,
        item: MediaItem
    ): PlayRequest? = build(context, store, item, Type.LIVE)

    suspend fun defaultHeaders(store: SettingsStore): Map<String, String> {
        val ua = store.userAgent.first()
        val ref = store.referer.first()
        return buildMap {
            if (ua.isNotBlank()) put("User-Agent", ua)
            if (ref.isNotBlank()) put("Referer", ref)
        }
    }

    fun encodeUrl(url: String): String =
        URLEncoder.encode(url, StandardCharsets.UTF_8.name())

    // --- intern ---

    private enum class Type { LIVE, VOD }

    private suspend fun build(
        context: Context,
        store: SettingsStore,
        item: MediaItem,
        type: Type
    ): PlayRequest? {
        val url = when {
            item.source == "TG" && item.tgChatId != null && item.tgMessageId != null ->
                "tg://message?chatId=${item.tgChatId}&messageId=${item.tgMessageId}"

            item.url != null -> item.url!!

            else -> {
                val streamId = item.streamId ?: return null
                val port = store.xtPort.first()
                val scheme = if (port == 443) "https" else "http"

                val http = HttpClientFactory.create(context, store)
                val client = XtreamClient(http)
                val caps = ProviderCapabilityStore(context)
                val ports = EndpointPortStore(context)
                client.initialize(
                    scheme = scheme,
                    host = store.xtHost.first(),
                    username = store.xtUser.first(),
                    password = store.xtPass.first(),
                    basePath = null,
                    store = caps,
                    portStore = ports,
                    portOverride = port
                )

                when (type) {
                    Type.LIVE -> client.buildLivePlayUrl(streamId)
                    Type.VOD  -> client.buildVodPlayUrl(streamId, null)
                }
            }
        } ?: return null

        return PlayRequest(url = url, headers = defaultHeaders(store))
    }
}
